const medicineProfiles = {
  sertraline: {
    name: "Sertraline",
    badge: "SSRI demo module",
    classLabel: "SSRI",
    target: "SERT",
    subtitle: "A premium visual guide to how sertraline, an SSRI antidepressant, can increase serotonin signalling between neurons over time.",
    mechanismTitle: "Serotonin signalling at the synapse",
    mechanismText: "Sertraline blocks the serotonin transporter, leaving more serotonin available in the synaptic gap.",
    facts: [
      ["Rx", "Drug class", "SSRI antidepressant", "Selective serotonin reuptake inhibitor used in mood and anxiety care."],
      ["Use", "Common uses", "Depression, anxiety, OCD", "Prescribed based on symptoms, diagnosis, response, and clinician judgment."],
      ["4-6", "Typical onset", "Several weeks", "Some early shifts may happen sooner, while mood benefit often builds gradually."],
      ["SE", "Common side effects", "Nausea, headache, insomnia", "Many early effects are temporary, but persistent symptoms need medical review."]
    ],
    timeline: [
      ["First days", "Body adapts", "Side effects can appear before clear mood improvement."],
      ["Week 2", "Early shifts", "Sleep, appetite, energy, or anxiety may begin to change."],
      ["Week 4", "Noticeable benefit", "Some people start to feel steadier emotional regulation."],
      ["Week 6", "Clinical review", "Doctors may review response, dose, side effects, and next steps."]
    ],
    effects: [
      ["Nausea", "Mild to moderate", "Common badge"],
      ["Headache", "Mild", "Temporary badge"],
      ["Insomnia", "Mild to moderate", "Common badge"],
      ["Dry mouth", "Mild", "Temporary badge"],
      ["Dizziness", "Mild to moderate", "Monitor badge"]
    ],
    warnings: [
      ["Alcohol interactions", "Alcohol can worsen sleepiness, mood symptoms, judgment, and medication tolerability."],
      ["Serotonin syndrome", "Urgent symptoms may include fever, confusion, sweating, agitation, tremor, or muscle rigidity."],
      ["Overdose warning", "Seek emergency help for overdose concerns, severe drowsiness, seizure, fainting, or dangerous behavior."],
      ["Stopping suddenly", "Stopping without guidance can cause withdrawal-like symptoms or symptom return."]
    ],
    faqs: [
      ["How long does sertraline take to work?", "Some early changes can happen within 1 to 2 weeks, but clearer mood benefit often takes 4 to 6 weeks or longer."],
      ["Can side effects happen first?", "Yes. Nausea, headache, sleep change, or restlessness may appear before mood benefit. Persistent or severe effects should be discussed with a clinician."],
      ["Is it addictive?", "Sertraline is not considered addictive in the way alcohol, opioids, or benzodiazepines can be, but stopping suddenly can still cause uncomfortable discontinuation symptoms."],
      ["Can I stop suddenly?", "Do not stop suddenly without medical guidance. A clinician may recommend a gradual taper depending on dose, duration, and symptoms."]
    ]
  },
  fluoxetine: {
    name: "Fluoxetine",
    badge: "SSRI demo module",
    classLabel: "SSRI",
    target: "SERT",
    subtitle: "A premium visual guide to how fluoxetine, an SSRI antidepressant, can support serotonin signalling across mood and anxiety circuits.",
    mechanismTitle: "Long-acting serotonin reuptake inhibition",
    mechanismText: "Fluoxetine blocks serotonin reuptake through SERT, helping serotonin remain available for receptor signalling in the synapse.",
    facts: [
      ["Rx", "Drug class", "SSRI antidepressant", "A selective serotonin reuptake inhibitor with a long-lasting active metabolite."],
      ["Use", "Common uses", "Depression, OCD, panic", "Also used in some anxiety-related and mood conditions when clinically appropriate."],
      ["2-6", "Typical onset", "Several weeks", "Energy or sleep may shift earlier, while mood response often needs more time."],
      ["SE", "Common side effects", "Nausea, insomnia, headache", "Early effects may settle, but activating symptoms should be monitored."]
    ],
    timeline: [
      ["First days", "Early adjustment", "Nausea, headache, or sleep changes may appear as the body adapts."],
      ["Week 2", "Subtle movement", "Energy, appetite, or anxiety patterns may begin to shift."],
      ["Week 4", "Response check", "Mood and intrusive symptoms may show clearer improvement for some people."],
      ["Week 6", "Treatment review", "Clinicians may review benefit, tolerability, adherence, and dose plan."]
    ],
    effects: [
      ["Nausea", "Mild to moderate", "Common badge"],
      ["Headache", "Mild", "Temporary badge"],
      ["Insomnia", "Mild to moderate", "Common badge"],
      ["Dry mouth", "Mild", "Temporary badge"],
      ["Dizziness", "Mild", "Monitor badge"]
    ],
    warnings: [
      ["Alcohol interactions", "Alcohol can worsen sleep, mood symptoms, concentration, and medication side effects."],
      ["Serotonin syndrome", "Risk can rise with other serotonergic medicines or supplements. Seek urgent help for fever, confusion, agitation, tremor, or rigidity."],
      ["Overdose warning", "Overdose concerns need emergency care, especially with severe agitation, seizure, fainting, or abnormal heartbeat."],
      ["Stopping suddenly", "Fluoxetine lasts longer than many SSRIs, but stopping should still be guided by a clinician."]
    ],
    faqs: [
      ["How long does fluoxetine take to work?", "Some early changes can appear in 1 to 2 weeks, but meaningful mood or OCD improvement often takes 4 to 6 weeks or longer."],
      ["Can side effects happen first?", "Yes. Nausea, insomnia, headache, or restlessness can happen before benefits become clear."],
      ["Is it addictive?", "Fluoxetine is not considered addictive, but medication changes should still be medically supervised."],
      ["Can I stop suddenly?", "Do not stop suddenly without medical guidance, even though fluoxetine stays in the body longer than many SSRIs."]
    ]
  },
  escitalopram: {
    name: "Escitalopram",
    badge: "SSRI demo module",
    classLabel: "SSRI",
    target: "SERT",
    subtitle: "A premium visual guide to how escitalopram, an SSRI antidepressant, can increase serotonin availability in mood and anxiety pathways.",
    mechanismTitle: "Selective serotonin transporter blockade",
    mechanismText: "Escitalopram selectively blocks SERT, reducing serotonin reuptake so signalling can continue longer in the synaptic gap.",
    facts: [
      ["Rx", "Drug class", "SSRI antidepressant", "A selective serotonin reuptake inhibitor commonly used in mood and anxiety care."],
      ["Use", "Common uses", "Depression, anxiety", "Often prescribed for major depression and generalized anxiety, depending on clinical assessment."],
      ["2-6", "Typical onset", "Several weeks", "Anxiety and sleep may shift earlier, while full benefit often takes weeks."],
      ["SE", "Common side effects", "Nausea, headache, insomnia", "Many side effects are early and temporary, but severe symptoms require medical advice."]
    ],
    timeline: [
      ["First days", "Initial adaptation", "Digestive, sleep, or mild nervous system effects can appear first."],
      ["Week 2", "Early settling", "Some people notice sleep, appetite, or anxiety beginning to settle."],
      ["Week 4", "Clearer effect", "Mood or worry symptoms may show more noticeable improvement."],
      ["Week 6", "Care plan review", "Clinicians may evaluate response, dose, tolerability, and next steps."]
    ],
    effects: [
      ["Nausea", "Mild to moderate", "Common badge"],
      ["Headache", "Mild", "Temporary badge"],
      ["Insomnia", "Mild to moderate", "Common badge"],
      ["Dry mouth", "Mild", "Temporary badge"],
      ["Dizziness", "Mild to moderate", "Monitor badge"]
    ],
    warnings: [
      ["Alcohol interactions", "Alcohol can increase sedation, worsen anxiety or depression, and reduce treatment consistency."],
      ["Serotonin syndrome", "Seek urgent help for fever, confusion, sweating, tremor, agitation, diarrhea, or muscle rigidity."],
      ["Overdose warning", "Overdose concerns require emergency help, especially with fainting, seizure, severe sleepiness, or heart rhythm symptoms."],
      ["Stopping suddenly", "Stopping suddenly can cause dizziness, electric-shock sensations, irritability, sleep changes, or symptom return."]
    ],
    faqs: [
      ["How long does escitalopram take to work?", "Some early changes may appear within 1 to 2 weeks, but fuller mood or anxiety improvement often takes 4 to 6 weeks."],
      ["Can side effects happen first?", "Yes. Nausea, headache, insomnia, or dizziness may happen before the intended benefit is obvious."],
      ["Is it addictive?", "Escitalopram is not considered addictive, but the body can react if it is stopped too quickly."],
      ["Can I stop suddenly?", "Do not stop suddenly without medical guidance. A gradual taper is often used to reduce discontinuation symptoms."]
    ]
  }
};

const aliases = {
  zoloft: "sertraline",
  prozac: "fluoxetine",
  lexapro: "escitalopram"
};

const params = new URLSearchParams(window.location.search);
const requestedMedicine = (params.get("med") || "sertraline").trim().toLowerCase();
const profileKey = aliases[requestedMedicine] || requestedMedicine;
const profile = medicineProfiles[profileKey] || medicineProfiles.sertraline;

const setText = (selector, text) => {
  const element = document.querySelector(selector);
  if (element) element.textContent = text;
};

const buildFactCards = (facts) => facts.map(([icon, label, value, text]) => `
  <article class="fact-card glass-card">
    <span class="fact-icon">${icon}</span>
    <small>${label}</small>
    <strong>${value}</strong>
    <p>${text}</p>
  </article>
`).join("");

const buildTimelineCards = (timeline) => timeline.map(([phase, title, text]) => `
  <article class="timeline-card glass-card">
    <span>${phase}</span>
    <strong>${title}</strong>
    <p>${text}</p>
  </article>
`).join("");

const buildEffectCards = (effects) => effects.map(([name, severity, badge]) => `
  <article class="effect-card glass-card">
    <span>${name}</span>
    <strong>${severity}</strong>
    <small>${badge}</small>
  </article>
`).join("");

const buildWarningCards = (warnings) => warnings.map(([title, text]) => `
  <article class="warning-card glass-card">
    <span>${title}</span>
    <p>${text}</p>
  </article>
`).join("");

const buildFaqItems = (faqs) => faqs.map(([question, answer], index) => `
  <article class="faq-item glass-card${index === 0 ? " is-open" : ""}">
    <button type="button" aria-expanded="${index === 0 ? "true" : "false"}">
      ${question}
      <span></span>
    </button>
    <div class="faq-panel">
      <p>${answer}</p>
    </div>
  </article>
`).join("");

const populateMedicinePage = () => {
  document.title = `${profile.name} | KNOW YOUR PILL`;
  setText("#moduleBadge", profile.badge);
  setText("#medicineName", profile.name);
  setText("#heroSubtitle", profile.subtitle);
  setText("#heroClass", profile.classLabel);
  setText("#heroTarget", profile.target);
  setText("#mechanismTitle", profile.mechanismTitle);
  setText("#mechanismText", profile.mechanismText);

  const heroVisual = document.querySelector("#heroVisual");
  if (heroVisual) heroVisual.setAttribute("aria-label", `${profile.name} neural signal preview`);

  const factGrid = document.querySelector("#factGrid");
  const timelineTrack = document.querySelector("#timelineTrack");
  const effectsGrid = document.querySelector("#effectsGrid");
  const warningGrid = document.querySelector(".warning-grid");
  const faqList = document.querySelector("#faqList");

  if (factGrid) factGrid.innerHTML = buildFactCards(profile.facts);
  if (timelineTrack) timelineTrack.innerHTML = buildTimelineCards(profile.timeline);
  if (effectsGrid) effectsGrid.innerHTML = buildEffectCards(profile.effects);
  if (warningGrid) warningGrid.innerHTML = buildWarningCards(profile.warnings);
  if (faqList) faqList.innerHTML = buildFaqItems(profile.faqs);
};

populateMedicinePage();

const fadeElements = document.querySelectorAll(".section-fade");
const timelineCards = document.querySelectorAll(".timeline-card");
const replayButton = document.querySelector("#replayAnimation");
const synapseStage = document.querySelector("#synapseStage");

// Reveal sections and timeline cards as they enter the viewport.
const revealObserver = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (!entry.isIntersecting) return;

    entry.target.classList.add("is-visible");
    revealObserver.unobserve(entry.target);
  });
}, { threshold: 0.18 });

fadeElements.forEach((element) => revealObserver.observe(element));
timelineCards.forEach((card, index) => {
  card.style.transitionDelay = `${index * 120}ms`;
  revealObserver.observe(card);
});

// Replay the synapse animation by temporarily restarting animated elements.
if (replayButton && synapseStage) {
  replayButton.addEventListener("click", () => {
    synapseStage.classList.add("is-replaying");

    window.setTimeout(() => {
      synapseStage.classList.remove("is-replaying");
    }, 80);
  });
}

const setupFaqAccordion = () => {
  const faqItems = document.querySelectorAll(".faq-item");

  faqItems.forEach((item) => {
    const button = item.querySelector("button");
    const panel = item.querySelector(".faq-panel");

    const setPanelHeight = () => {
      if (!panel) return;
      panel.style.maxHeight = item.classList.contains("is-open")
        ? `${panel.scrollHeight}px`
        : "0px";
    };

    setPanelHeight();

    button?.addEventListener("click", () => {
      const wasOpen = item.classList.contains("is-open");

      faqItems.forEach((otherItem) => {
        otherItem.classList.remove("is-open");
        otherItem.querySelector("button")?.setAttribute("aria-expanded", "false");
        const otherPanel = otherItem.querySelector(".faq-panel");
        if (otherPanel) otherPanel.style.maxHeight = "0px";
      });

      if (!wasOpen) {
        item.classList.add("is-open");
        button.setAttribute("aria-expanded", "true");
        setPanelHeight();
      }
    });
  });
};

setupFaqAccordion();

window.addEventListener("resize", () => {
  document.querySelectorAll(".faq-item.is-open .faq-panel").forEach((panel) => {
    panel.style.maxHeight = `${panel.scrollHeight}px`;
  });
});

// Mobile menu toggle functionality
const setupMobileMenu = () => {
  const menuToggle = document.querySelector("#menuToggle");
  const siteNav = document.querySelector("#siteNav");

  if (!menuToggle || !siteNav) return;

  menuToggle.addEventListener("click", () => {
    const isOpen = menuToggle.classList.toggle("is-open");
    menuToggle.setAttribute("aria-expanded", isOpen);

    if (isOpen) {
      siteNav.style.display = "flex";
      siteNav.style.flexDirection = "column";
      siteNav.style.position = "absolute";
      siteNav.style.top = "100%";
      siteNav.style.left = "0";
      siteNav.style.right = "0";
      siteNav.style.padding = "12px";
      siteNav.style.background = "rgba(255, 255, 255, 0.95)";
      siteNav.style.borderRadius = "0 0 8px 8px";
      siteNav.style.boxShadow = "0 12px 40px rgba(31, 46, 72, 0.15)";
    } else {
      siteNav.style.display = "";
      siteNav.style.flexDirection = "";
      siteNav.style.position = "";
      siteNav.style.top = "";
      siteNav.style.left = "";
      siteNav.style.right = "";
      siteNav.style.padding = "";
      siteNav.style.background = "";
      siteNav.style.borderRadius = "";
      siteNav.style.boxShadow = "";
    }
  });

  // Close menu when clicking outside
  document.addEventListener("click", (e) => {
    if (!siteNav.contains(e.target) && !menuToggle.contains(e.target)) {
      menuToggle.classList.remove("is-open");
      menuToggle.setAttribute("aria-expanded", "false");
      siteNav.style.display = "";
      siteNav.style.flexDirection = "";
      siteNav.style.position = "";
      siteNav.style.top = "";
      siteNav.style.left = "";
      siteNav.style.right = "";
      siteNav.style.padding = "";
      siteNav.style.background = "";
      siteNav.style.borderRadius = "";
      siteNav.style.boxShadow = "";
    }
  });
};

setupMobileMenu();
