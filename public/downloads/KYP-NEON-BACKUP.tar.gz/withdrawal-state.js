/**
 * Withdrawal State - Interactive Neuroscience Education
 * KNOW YOUR PILL Platform
 */

document.addEventListener('DOMContentLoaded', function() {
  // Initialize all interactive features
  initScrollAnimations();
  initBrainRegionInteractions();
  initTimelineAnimations();
  initEmergencyPulseEffects();
  initSubstanceCardEffects();
  initWaveAnimations();
});

/**
 * Scroll-triggered reveal animations using Intersection Observer
 */
function initScrollAnimations() {
  const revealSections = document.querySelectorAll('.reveal-section');
  
  const observerOptions = {
    root: null,
    rootMargin: '0px',
    threshold: 0.1
  };
  
  const observer = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('revealed');
        observer.unobserve(entry.target);
      }
    });
  }, observerOptions);
  
  revealSections.forEach(section => {
    observer.observe(section);
  });
}

/**
 * Interactive brain region cards with hover effects
 */
function initBrainRegionInteractions() {
  const brainRegions = document.querySelectorAll('.brain-region');
  
  brainRegions.forEach(region => {
    // Add hover sound effect (subtle)
    region.addEventListener('mouseenter', function() {
      this.style.transition = 'all 0.4s cubic-bezier(0.4, 0, 0.2, 1)';
      
      // Add ripple effect
      const glow = this.querySelector('.region-glow');
      if (glow) {
        glow.style.animation = 'none';
        setTimeout(() => {
          glow.style.animation = 'regionPulse 2s ease-in-out infinite';
        }, 10);
      }
    });
    
    region.addEventListener('mouseleave', function() {
      const glow = this.querySelector('.region-glow');
      if (glow) {
        glow.style.animation = '';
      }
    });
    
    // Click to show more info
    region.addEventListener('click', function() {
      const label = this.querySelector('.region-label')?.textContent;
      const title = this.querySelector('h4')?.textContent;
      const desc = this.querySelector('p')?.textContent;
      
      if (label && title && desc) {
        showRegionInfo(label, title, desc);
      }
    });
  });
  
  // Add CSS for region pulse animation
  const style = document.createElement('style');
  style.textContent = `
    @keyframes regionPulse {
      0%, 100% { 
        opacity: 0.5; 
        transform: scale(1);
      }
      50% { 
        opacity: 1; 
        transform: scale(1.5);
      }
    }
  `;
  document.head.appendChild(style);
}

/**
 * Show detailed information about a brain region
 */
function showRegionInfo(label, title, description) {
  // Create modal overlay
  const overlay = document.createElement('div');
  overlay.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.7);
    backdrop-filter: blur(8px);
    z-index: 1000;
    display: flex;
    align-items: center;
    justify-content: center;
    animation: fadeIn 0.3s ease;
  `;
  
  const modal = document.createElement('div');
  modal.style.cssText = `
    background: linear-gradient(135deg, rgba(99, 102, 241, 0.95), rgba(139, 92, 246, 0.95));
    border-radius: 24px;
    padding: 40px;
    max-width: 500px;
    width: 90%;
    color: white;
    position: relative;
    animation: slideUp 0.4s ease;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
  `;
  
  modal.innerHTML = `
    <button style="
      position: absolute;
      top: 16px;
      right: 16px;
      background: rgba(255, 255, 255, 0.2);
      border: none;
      color: white;
      width: 32px;
      height: 32px;
      border-radius: 50%;
      font-size: 18px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: background 0.3s;
    " onclick="this.parentElement.parentElement.remove()">×</button>
    <span style="
      font-size: 12px;
      text-transform: uppercase;
      letter-spacing: 2px;
      opacity: 0.8;
    ">${label}</span>
    <h3 style="font-size: 28px; margin: 8px 0 16px; font-weight: 700;">${title}</h3>
    <p style="font-size: 16px; line-height: 1.7; opacity: 0.9;">${description}</p>
    <p style="font-size: 13px; opacity: 0.6; margin-top: 20px;">
      During withdrawal, this brain region undergoes significant changes that contribute to the symptoms experienced.
    </p>
  `;
  
  overlay.appendChild(modal);
  document.body.appendChild(overlay);
  
  // Close on overlay click
  overlay.addEventListener('click', function(e) {
    if (e.target === overlay) {
      overlay.remove();
    }
  });
  
  // Add animations
  const animStyle = document.createElement('style');
  animStyle.textContent = `
    @keyframes fadeIn {
      from { opacity: 0; }
      to { opacity: 1; }
    }
    @keyframes slideUp {
      from { opacity: 0; transform: translateY(30px); }
      to { opacity: 1; transform: translateY(0); }
    }
  `;
  document.head.appendChild(animStyle);
}

/**
 * Timeline phase animations
 */
function initTimelineAnimations() {
  const phases = document.querySelectorAll('.timeline-phase');
  
  const observerOptions = {
    root: null,
    rootMargin: '0px',
    threshold: 0.3
  };
  
  const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry, index) => {
      if (entry.isIntersecting) {
        setTimeout(() => {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateX(0)';
        }, index * 150);
      }
    });
  }, observerOptions);
  
  phases.forEach(phase => {
    phase.style.opacity = '0';
    phase.style.transform = 'translateX(-20px)';
    phase.style.transition = 'all 0.6s ease-out';
    observer.observe(phase);
  });
}

/**
 * Emergency pulse effects for critical sections
 */
function initEmergencyPulseEffects() {
  const emergencyCards = document.querySelectorAll('.emergency-sign-card');
  
  emergencyCards.forEach((card, index) => {
    // Stagger the pulse animations
    card.style.animationDelay = `${index * 0.1}s`;
    
    // Add interactive glow on hover
    card.addEventListener('mouseenter', function() {
      this.style.boxShadow = '0 0 30px rgba(239, 68, 68, 0.3)';
    });
    
    card.addEventListener('mouseleave', function() {
      this.style.boxShadow = '';
    });
  });
}

/**
 * Substance card hover effects
 */
function initSubstanceCardEffects() {
  const substanceCards = document.querySelectorAll('.substance-detail-card');
  
  substanceCards.forEach(card => {
    card.addEventListener('mouseenter', function() {
      // Add subtle scale effect
      this.style.transform = 'translateY(-8px) scale(1.02)';
    });
    
    card.addEventListener('mouseleave', function() {
      this.style.transform = '';
    });
    
    // Add click to expand functionality
    card.addEventListener('click', function() {
      const header = this.querySelector('.substance-info h3')?.textContent;
      const emoji = this.querySelector('.substance-emoji')?.textContent;
      const body = this.querySelector('.substance-body')?.innerHTML;
      
      if (header && body) {
        showSubstanceDetail(emoji, header, body);
      }
    });
  });
}

/**
 * Show detailed substance information
 */
function showSubstanceDetail(emoji, title, bodyContent) {
  const overlay = document.createElement('div');
  overlay.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.7);
    backdrop-filter: blur(8px);
    z-index: 1000;
    display: flex;
    align-items: center;
    justify-content: center;
    animation: fadeIn 0.3s ease;
  `;
  
  const modal = document.createElement('div');
  modal.style.cssText = `
    background: linear-gradient(135deg, rgba(99, 102, 241, 0.95), rgba(139, 92, 246, 0.95));
    border-radius: 24px;
    padding: 40px;
    max-width: 600px;
    width: 90%;
    color: white;
    position: relative;
    animation: slideUp 0.4s ease;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
  `;
  
  modal.innerHTML = `
    <button style="
      position: absolute;
      top: 16px;
      right: 16px;
      background: rgba(255, 255, 255, 0.2);
      border: none;
      color: white;
      width: 32px;
      height: 32px;
      border-radius: 50%;
      font-size: 18px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: background 0.3s;
    " onclick="this.parentElement.parentElement.remove()">×</button>
    <div style="text-align: center; margin-bottom: 24px;">
      <span style="font-size: 64px;">${emoji}</span>
      <h3 style="font-size: 28px; margin: 16px 0; font-weight: 700;">${title}</h3>
    </div>
    <div style="background: rgba(255, 255, 255, 0.1); border-radius: 16px; padding: 24px;">
      ${bodyContent}
    </div>
    <p style="font-size: 13px; opacity: 0.6; margin-top: 20px; text-align: center;">
      Withdrawal symptoms vary by substance type, duration of use, and individual factors.
    </p>
  `;
  
  overlay.appendChild(modal);
  document.body.appendChild(overlay);
  
  overlay.addEventListener('click', function(e) {
    if (e.target === overlay) {
      overlay.remove();
    }
  });
}

/**
 * Enhanced wave animations for hero section
 */
function initWaveAnimations() {
