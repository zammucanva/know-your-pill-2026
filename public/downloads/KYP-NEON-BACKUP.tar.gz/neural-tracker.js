/**
 * ============================================
 * NEURAL LEARNING NAVIGATION TRACKER
 * Premium neuroscience-inspired progress system
 * ============================================
 */

(function () {
  'use strict';

  // Configuration
  const CONFIG = {
    scrollOffset: 160, // Offset for scroll position calculation
    scrollDebounce: 100, // Debounce time for scroll events
    animationDuration: 600, // Duration for progress animations
    smoothScrollDuration: 800, // Duration for smooth scroll to section
  };

  // Section label mapping
  const SECTION_LABELS = {
    'opioid-overview': 'Understanding Opioids',
    'classification': 'Opioid Types',
    'neurobiology': 'Brain Mechanisms',
    'intoxication': 'Intoxication Effects',
    'withdrawal': 'Withdrawal Syndrome',
    'treatment': 'Treatment Options',
    'recovery': 'Recovery Pathways',
    'barb-overview': 'Understanding Barbiturates',
    'alcohol-overview': 'Understanding Alcohol',
    'cannabis-overview': 'Understanding Cannabis',
    'cocaine-overview': 'Understanding Cocaine',
    'amphetamine-overview': 'Understanding Amphetamines',
    'benzo-overview': 'Understanding Benzodiazepines',
    'lsd-overview': 'Understanding LSD',
    'nicotine-overview': 'Understanding Nicotine',
    'inhalant-overview': 'Understanding Inhalants',
    'pcp-overview': 'Understanding PCP',
    'default': 'Learning Module'
  };

  /**
   * NeuralTracker Class
   * Manages the neural progress navigation system
   */
  class NeuralTracker {
    constructor() {
      this.tracker = null;
      this.nodes = [];
      this.sections = [];
      this.currentIndex = 0;
      this.scrollTimeout = null;
      this.isInitialized = false;

      this.init();
    }

    /**
     * Initialize the tracker
     */
    init() {
      // Wait for DOM to be ready
      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => this.setup());
      } else {
        this.setup();
      }
    }

    /**
     * Setup the tracker after DOM is ready
     */
    setup() {
      this.tracker = document.querySelector('.neural-tracker');
      if (!this.tracker) return;

      this.nodes = Array.from(this.tracker.querySelectorAll('.neural-node'));
      this.sections = this.nodes.map(node => {
        const href = node.getAttribute('href');
        if (href && href.startsWith('#')) {
          return document.getElementById(href.substring(1));
        }
        return null;
      }).filter(Boolean);

      if (this.nodes.length === 0 || this.sections.length === 0) return;

      this.bindEvents();
      this.updateProgress();
      this.isInitialized = true;
    }

    /**
     * Bind scroll and click events
     */
    bindEvents() {
      // Scroll handler with debounce
      const handleScroll = () => {
        if (this.scrollTimeout) {
          cancelAnimationFrame(this.scrollTimeout);
        }
        this.scrollTimeout = requestAnimationFrame(() => {
          this.updateProgress();
        });
      };

      window.addEventListener('scroll', handleScroll, { passive: true });
      window.addEventListener('resize', () => this.updateProgress());

      // Node click handlers
      this.nodes.forEach((node, index) => {
        node.addEventListener('click', (e) => this.handleNodeClick(e, index));
      });
    }

    /**
     * Handle node click - smooth scroll to section
     */
    handleNodeClick(e, index) {
      e.preventDefault();
      const section = this.sections[index];
      if (!section) return;

      // Update active state immediately for responsiveness
      this.setActiveNode(index);

      // Smooth scroll to section
      const offsetTop = section.offsetTop - CONFIG.scrollOffset;
      window.scrollTo({
        top: offsetTop,
        behavior: 'smooth'
      });
    }

    /**
     * Update progress based on scroll position
     */
    updateProgress() {
      const scrollY = window.scrollY;
      const viewportHeight = window.innerHeight;
      let activeIndex = 0;

      // Find the current active section
      this.sections.forEach((section, index) => {
        if (section) {
          const sectionTop = section.offsetTop - CONFIG.scrollOffset;
          const sectionBottom = sectionTop + section.offsetHeight;

          if (scrollY >= sectionTop - viewportHeight * 0.3 ||
              (scrollY + viewportHeight >= sectionBottom && index === this.sections.length - 1)) {
            // Check if this section is the best match
            if (scrollY < sectionBottom || index === this.sections.length - 1) {
              activeIndex = index;
            }
          }

          // Alternative: check if section top is visible in viewport
          if (sectionTop <= scrollY + viewportHeight * 0.5) {
            activeIndex = index;
          }
        }
      });

      // Refine: find the section whose top is closest to the offset point
      let closestIndex = 0;
      let closestDistance = Infinity;

      this.sections.forEach((section, index) => {
        if (section) {
          const sectionTop = section.offsetTop - CONFIG.scrollOffset;
          const distance = Math.abs(scrollY - sectionTop);
          if (distance < closestDistance) {
            closestDistance = distance;
            closestIndex = index;
          }
        }
      });

      // Use closest section if it's reasonably close
      if (closestDistance < viewportHeight * 0.5) {
        activeIndex = closestIndex;
      }

      this.setActiveNode(activeIndex);
      this.updateProgressFill(activeIndex);
      this.updateStatusLabel(activeIndex);
    }

    /**
     * Set the active node and update all node states
     */
    setActiveNode(index) {
      if (index === this.currentIndex) return;
      this.currentIndex = index;

      this.nodes.forEach((node, i) => {
        // Remove all state classes
        node.classList.remove('neural-node--active', 'neural-node--inactive', 'neural-node--complete');

        if (i < index) {
          node.classList.add('neural-node--complete');
        } else if (i === index) {
          node.classList.add('neural-node--active');
        } else {
          node.classList.add('neural-node--inactive');
        }
      });
    }

    /**
     * Update the progress fill line
     */
    updateProgressFill(index) {
      const fill = this.tracker.querySelector('.neural-track__fill');
      if (!fill || this.nodes.length <= 1) return;

      // Calculate progress percentage based on node position
      const totalNodes = this.nodes.length;
      const progress = (index / (totalNodes - 1)) * 100;
      fill.style.width = `${progress}%`;
    }

    /**
     * Update the section status label
     */
    updateStatusLabel(index) {
      const labelEl = this.tracker.querySelector('.neural-tracker__label');
      const percentEl = this.tracker.querySelector('.neural-tracker__value');
      if (!labelEl || !percentEl) return;

      // Get section ID from the active node
      const activeNode = this.nodes[index];
      const href = activeNode.getAttribute('href');
      let sectionId = 'default';

      if (href && href.startsWith('#')) {
        sectionId = href.substring(1);
      }

      // Get the appropriate label
      const label = SECTION_LABELS[sectionId] || SECTION_LABELS.default;
      labelEl.textContent = label;

      // Update percentage
      const totalNodes = this.nodes.length;
      const percent = Math.round((index / (totalNodes - 1)) * 100);
      percentEl.textContent = `${percent}%`;
    }

    /**
     * Get current progress percentage
     */
    getProgress() {
      return Math.round((this.currentIndex / (this.nodes.length - 1)) * 100);
    }

    /**
     * Reset tracker to initial state
     */
    reset() {
      this.currentIndex = 0;
      this.setActiveNode(0);
      this.updateProgressFill(0);
      this.updateStatusLabel(0);
    }
  }

  // Initialize tracker when DOM is ready
  let trackerInstance = null;

  function initTracker() {
    if (!trackerInstance) {
      trackerInstance = new NeuralTracker();
    }
  }

  // Auto-initialize
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initTracker);
  } else {
    initTracker();
  }

  // Expose to global scope for external access if needed
  window.NeuralTracker = {
    getInstance: () => trackerInstance,
    init: initTracker
  };

})();