/* ============================================
   ACUTE INTOXICATION PAGE INTERACTIVITY
   Neuroscience Education Platform
   ============================================ */

document.addEventListener('DOMContentLoaded', function() {
  // ============================================
  // Neural Pathway Progress Tracker
  // ============================================
  const progressNodes = document.querySelectorAll('.progress-node');
  const sections = ['simple-explanation', 'clinical-overview', 'substances', 'brain-effects', 'emergency-signs', 'recovery-support'];
  const progressPercentage = document.querySelector('.progress-percentage');
  
  // Click handler for progress nodes
  progressNodes.forEach(node => {
    node.addEventListener('click', function(e) {
      e.preventDefault();
      const href = this.getAttribute('href');
      if (href && href.startsWith('#')) {
        const target = document.querySelector(href);
        if (target) {
          target.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
          });
        }
      }
    });
  });
  
  // Scroll-based progress tracking
  function updateProgressTracker() {
    const scrollPosition = window.scrollY + window.innerHeight / 3;
    let activeIndex = 0;
    
    sections.forEach((sectionId, index) => {
      const section = document.getElementById(sectionId);
      if (section && scrollPosition >= section.offsetTop - 100) {
        activeIndex = index;
      }
    });
    
    // Update node states
    progressNodes.forEach((node, index) => {
      node.classList.remove('is-active', 'is-complete');
      if (index < activeIndex) {
        node.classList.add('is-complete');
      } else if (index === activeIndex) {
        node.classList.add('is-active');
      }
    });
    
    // Update percentage
    const percentage = Math.round((activeIndex / (sections.length - 1)) * 100);
    if (progressPercentage) {
      progressPercentage.textContent = percentage;
    }
  }
  
  window.addEventListener('scroll', updateProgressTracker);
  updateProgressTracker(); // Initial call

  // ============================================
  // Brain Region Interactive Cards
  // ============================================
  const brainRegions = document.querySelectorAll('.brain-region');
  
  brainRegions.forEach(region => {
    region.addEventListener('mouseenter', function() {
      const regionInfo = this.querySelector('.region-info');
      const regionGlow = this.querySelector('.region-glow');
      
      // Enhance glow on hover
      if (regionGlow) {
        regionGlow.style.transform = 'scale(1.3)';
        regionGlow.style.opacity = '1';
      }
      
      // Animate region info
      if (regionInfo) {
        regionInfo.style.transform = 'translateY(-4px)';
      }
    });
    
    region.addEventListener('mouseleave', function() {
      const regionInfo = this.querySelector('.region-info');
      const regionGlow = this.querySelector('.region-glow');
      
      if (regionGlow) {
        regionGlow.style.transform = 'scale(1)';
        regionGlow.style.opacity = '0.6';
      }
      
      if (regionInfo) {
        regionInfo.style.transform = 'translateY(0)';
      }
    });
  });

  // ============================================
  // Interactive Cards Click Handler
  // ============================================
  const interactiveCards = document.querySelectorAll('.interactive-card');
  
  interactiveCards.forEach(card => {
    card.addEventListener('click', function() {
      const module = this.dataset.module;
      
      // Scroll to brain animation section
      if (module === 'brain-animation') {
        document.getElementById('brain-animation').scrollIntoView({ 
          behavior: 'smooth', 
          block: 'start' 
        });
      } else if (module === 'emergency-flags') {
        document.getElementById('emergency-signs').scrollIntoView({ 
          behavior: 'smooth', 
          block: 'start' 
        });
      } else if (module === 'substance-compare') {
        document.getElementById('substances').scrollIntoView({ 
          behavior: 'smooth', 
          block: 'start' 
        });
      } else if (module === 'behavior-changes') {
        document.getElementById('brain-effects').scrollIntoView({ 
          behavior: 'smooth', 
          block: 'start' 
        });
      } else if (module === 'when-to-seek') {
        document.getElementById('emergency-signs').scrollIntoView({ 
          behavior: 'smooth', 
          block: 'start' 
        });
      }
    });
  });

  // ============================================
  // Neurotransmitter Visualization Controls
  // ============================================
  const visButtons = document.querySelectorAll('.vis-btn');
  const visDescription = document.getElementById('visDescription');
  
  const neurotransmitterData = {
    dopamine: {
      title: 'Dopamine Pathway Activation',
      description: 'During intoxication, many substances trigger excessive dopamine release in the reward pathway. This creates intense feelings of pleasure and reinforces the desire to repeat substance use. The nucleus accumbens receives a flood of dopamine, creating euphoria and strengthening the association between substance use and reward.',
      color: '#f97316'
    },
    gaba: {
      title: 'GABA Enhancement (Calming Effect)',
      description: 'Depressant substances like alcohol and benzodiazepines enhance GABA activity — the brain\'s primary inhibitory neurotransmitter. This slows neural firing throughout the brain, producing sedation, relaxation, and reduced anxiety. However, excessive GABA enhancement can dangerously suppress breathing and consciousness.',
      color: '#8b5cf6'
    },
    glutamate: {
      title: 'Glutamate Suppression (Disruption)',
      description: 'Many intoxicating substances suppress glutamate — the brain\'s main excitatory neurotransmitter. This disruption impairs learning, memory formation, and cognitive function. Reduced glutamate activity contributes to confusion, memory gaps (blackouts), and slowed thinking during intoxication.',
      color: '#10b981'
    }
  };
  
  visButtons.forEach(btn => {
    btn.addEventListener('click', function() {
      // Remove active class from all buttons
      visButtons.forEach(b => b.classList.remove('active'));
      
      // Add active class to clicked button
      this.classList.add('active');
      
      // Update description
      const neuroType = this.dataset.vis;
      const data = neurotransmitterData[neuroType];
      
      if (data && visDescription) {
        visDescription.style.opacity = '0';
        
        setTimeout(() => {
          visDescription.querySelector('h4').textContent = data.title;
          visDescription.querySelector('p').textContent = data.description;
          visDescription.querySelector('h4').style.color = data.color;
          visDescription.style.opacity = '1';
        }, 200);
      }
      
      // Update synapse animation colors
      updateSynapseAnimation(neuroType);
    });
  });
  
  function updateSynapseAnimation(type) {
    const ntParticles = document.querySelectorAll('.nt-particle');
    const vesicles = document.querySelectorAll('.vesicle');
    
    let color1, color2;
    
    switch(type) {
      case 'dopamine':
        color1 = '#f97316';
        color2 = '#ef4444';
        break;
      case 'gaba':
        color1 = '#8b5cf6';
        color2 = '#6366f1';
        break;
      case 'glutamate':
        color1 = '#10b981';
        color2 = '#059669';
        break;
    }
    
    ntParticles.forEach((particle, index) => {
      particle.style.background = `linear-gradient(135deg, ${color1}, ${color2})`;
      particle.style.animationDelay = `${index * 0.3}s`;
    });
    
    vesicles.forEach(vesicle => {
      vesicle.style.background = `linear-gradient(135deg, ${color1}, ${color2})`;
    });
  }

  // ============================================
  // Timeline Phase Animations
  // ============================================
  const timelinePhases = document.querySelectorAll('.timeline-phase');
  
  const observerOptions = {
    threshold: 0.2,
    rootMargin: '0px'
  };
  
  const phaseObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateX(0)';
      }
    });
  }, observerOptions);
  
  timelinePhases.forEach(phase => {
    phase.style.opacity = '0';
    phase.style.transform = 'translateX(-20px)';
    phase.style.transition = 'all 0.6s ease';
    phaseObserver.observe(phase);
  });

  // ============================================
  // Emergency Card Hover Effects
  // ============================================
  const emergencyCards = document.querySelectorAll('.emergency-sign-card');
  
  emergencyCards.forEach(card => {
    card.addEventListener('mouseenter', function() {
      this.style.transform = 'translateY(-4px) scale(1.02)';
    });
    
    card.addEventListener('mouseleave', function() {
      this.style.transform = 'translateY(0) scale(1)';
    });
  });

  // ============================================
  // Substance Card Animations
  // ============================================
  const substanceCards = document.querySelectorAll('.substance-detail-card');
  
  substanceCards.forEach(card => {
    card.addEventListener('mouseenter', function() {
      // Add subtle scale effect
      this.style.transform = 'translateY(-8px)';
    });
    
    card.addEventListener('mouseleave', function() {
      this.style.transform = 'translateY(0)';
    });
  });

  // ============================================
  // Smooth Scroll for CTA Buttons
  // ============================================
  const ctaButtons = document.querySelectorAll('.cta-button');
  
  ctaButtons.forEach(btn => {
    btn.addEventListener('click', function(e) {
      const href = this.getAttribute('href');
      
      if (href.startsWith('#')) {
        e.preventDefault();
        const target = document.querySelector(href);
        
        if (target) {
          target.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
          });
        }
      }
    });
  });

  // ============================================
  // Symptom List Stagger Animation
  // ============================================
  const symptomCards = document.querySelectorAll('.symptom-category-card');
  
  const symptomObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry, index) => {
      if (entry.isIntersecting) {
        setTimeout(() => {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
        }, index * 100);
      }
    });
  }, { threshold: 0.1 });
  
  symptomCards.forEach(card => {
    card.style.opacity = '0';
    card.style.transform = 'translateY(20px)';
    card.style.transition = 'all 0.5s ease';
    symptomObserver.observe(card);
  });

  // ============================================
  // Clinical Cards Stagger Animation
  // ============================================
  const clinicalCards = document.querySelectorAll('.clinical-card');
  
  const clinicalObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry, index) => {
      if (entry.isIntersecting) {
        setTimeout(() => {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0) scale(1)';
        }, index * 150);
      }
    });
  }, { threshold: 0.1 });
  
  clinicalCards.forEach(card => {
    card.style.opacity = '0';
    card.style.transform = 'translateY(20px) scale(0.95)';
    card.style.transition = 'all 0.5s ease';
    clinicalObserver.observe(card);
  });

  // ============================================
  // Neuro Mechanism Cards Animation
  // ============================================
  const mechanismCards = document.querySelectorAll('.neuro-mechanism-card');
  
  const mechanismObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateX(0)';
      }
    });
  }, { threshold: 0.1 });
  
  mechanismCards.forEach((card, index) => {
    card.style.opacity = '0';
    card.style.transform = index % 2 === 0 ? 'translateX(-30px)' : 'translateX(30px)';
    card.style.transition = 'all 0.7s ease';
    mechanismObserver.observe(card);
  });

  // ============================================
  // Support Cards Animation
  // ============================================
  const supportCards = document.querySelectorAll('.support-card');
  
  const supportObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry, index) => {
      if (entry.isIntersecting) {
        setTimeout(() => {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
        }, index * 200);
      }
    });
  }, { threshold: 0.1 });
  
  supportCards.forEach(card => {
    card.style.opacity = '0';
    card.style.transform = 'translateY(30px)';
    card.style.transition = 'all 0.6s ease';
    supportObserver.observe(card);
  });

  // ============================================
  // Interactive Module Cards Animation
  // ============================================
  const moduleCards = document.querySelectorAll('.interactive-card');
  
  const moduleObserver = new IntersectionObserver((entries) => {
    entries.forEach((entry, index) => {
      if (entry.isIntersecting) {
        setTimeout(() => {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0) scale(1)';
        }, index * 100);
      }
    });
  }, { threshold: 0.1 });
  
  moduleCards.forEach(card => {
    card.style.opacity = '0';
    card.style.transform = 'translateY(20px) scale(0.95)';
    card.style.transition = 'all 0.5s ease';
    moduleObserver.observe(card);
  });

  // ============================================
  // Brain Visualization Animation
  // ============================================
  const brainAnimationSection = document.getElementById('brain-animation');
  
  if (brainAnimationSection) {
    const brainVisObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
        }
      });
    }, { threshold: 0.2 });
    
    brainAnimationSection.style.opacity = '0';
    brainAnimationSection.style.transform = 'translateY(30px)';
    brainAnimationSection.style.transition = 'all 0.8s ease';
    brainVisObserver.observe(brainAnimationSection);
  }

  // ============================================
  // Parallax Effect for Hero Section
  // ============================================
  const heroVisual = document.querySelector('.intoxication-hero-visual');
  
  if (heroVisual) {
    document.addEventListener('mousemove', (e) => {
      const mouseX = e.clientX / window.innerWidth - 0.5;
      const mouseY = e.clientY / window.innerHeight - 0.5;
      
      heroVisual.style.transform = `translate(${mouseX * 20}px, ${mouseY * 20}px)`;
    });
  }

  // ============================================
  // Active Region Pulse Enhancement
  // ============================================
  const activeRegions = document.querySelectorAll('.active-region');
  
  activeRegions.forEach((region, index) => {
    // Stagger the pulse animations
    region.style.animationDelay = `${index * 0.3}s`;
  });

  // ============================================
  // Emergency Call Button Pulse
  // ============================================
  const emergencyCallBtn = document.querySelector('.emergency-call-button');
  
  if (emergencyCallBtn) {
    emergencyCallBtn.addEventListener('click', function() {
      // Add a brief visual feedback
      this.style.transform = 'scale(0.95)';
      setTimeout(() => {
        this.style.transform = '';
      }, 150);
    });
  }

  // ============================================
  // Explanation Section Reveal
  // ============================================
  const explanationSection = document.getElementById('simple-explanation');
  
  if (explanationSection) {
    const explanationObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.style.opacity = '1';
          entry.target.style.transform = 'translateY(0)';
        }
      });
    }, { threshold: 0.1 });
    
    explanationSection.style.opacity = '0';
    explanationSection.style.transform = 'translateY(30px)';
    explanationSection.style.transition = 'all 0.7s ease';
    explanationObserver.observe(explanationSection);
  }

  // ============================================
  // Substance Types Grid Stagger
  // ============================================
  const substanceTypeCards = document.querySelectorAll('.substance-type-card');
  
  substanceTypeCards.forEach((card, index) => {
    card.style.opacity = '0';
    card.style.transform = 'translateY(20px)';
    card.style.transition = `all 0.5s ease ${index * 0.1}s`;
    
    setTimeout(() => {
      card.style.opacity = '1';
      card.style.transform = 'translateY(0)';
    }, 500 + index * 100);
  });

  // ============================================
  // Experience Items Stagger
  // ============================================
  const experienceItems = document.querySelectorAll('.experience-item');
  
  experienceItems.forEach((item, index) => {
    item.style.opacity = '0';
    item.style.transform = 'scale(0.9)';
    item.style.transition = `all 0.4s ease ${index * 0.08}s`;
    
    setTimeout(() => {
      item.style.opacity = '1';
      item.style.transform = 'scale(1)';
    }, 800 + index * 80);
  });

  // ============================================
  // Severity Notice Animation
  // ============================================
  const severityNotice = document.querySelector('.severity-notice');
  
  if (severityNotice) {
    severityNotice.style.opacity = '0';
    severityNotice.style.transform = 'translateY(20px)';
    severityNotice.style.transition = 'all 0.6s ease 1.5s';
    
    setTimeout(() => {
      severityNotice.style.opacity = '1';
      severityNotice.style.transform = 'translateY(0)';
    }, 1500);
  }

  // ============================================
  // Feature Chips Animation
  // ============================================
  const featureChips = document.querySelectorAll('.feature-chip');
  
  featureChips.forEach((chip, index) => {
    chip.style.opacity = '0';
    chip.style.transform = 'scale(0.8)';
    chip.style.transition = `all 0.3s ease ${index * 0.05}s`;
    
    setTimeout(() => {
      chip.style.opacity = '1';
      chip.style.transform = 'scale(1)';
    }, 1000 + index * 50);
  });

  // ============================================
  // Region Chips Animation
  // ============================================
  const regionChips = document.querySelectorAll('.region-chip');
  
  regionChips.forEach((chip, index) => {
    chip.style.opacity = '0';
    chip.style.transform = 'translateX(-10px)';
    chip.style.transition = `all 0.3s ease ${index * 0.05}s`;
    
    setTimeout(() => {
      chip.style.opacity = '1';
      chip.style.transform = 'translateX(0)';
    }, 1500 + index * 50);
  });

  // ============================================
  // Function Chips Animation
  // ============================================
  const functionChips = document.querySelectorAll('.function-chip');
  
  functionChips.forEach((chip, index) => {
    chip.style.opacity = '0';
    chip.style.transform = 'translateX(-10px)';
    chip.style.transition = `all 0.3s ease ${index * 0.05}s`;
    
    setTimeout(() => {
      chip.style.opacity = '1';
      chip.style.transform = 'translateX(0)';
    }, 1500 + index * 50);
  });

  // ============================================
  // Substance Badges Animation
  // ============================================
  const substanceBadges = document.querySelectorAll('.substance-badge');
  
  substanceBadges.forEach((badge, index) => {
    badge.style.opacity = '0';
    badge.style.transform = 'scale(0.8)';
    badge.style.transition = `all 0.3s ease ${index * 0.1}s`;
    
    setTimeout(() => {
      badge.style.opacity = '1';
      badge.style.transform = 'scale(1)';
    }, 1200 + index * 100);
  });

  // ============================================
  // Danger Badges Animation
  // ============================================
  const dangerBadges = document.querySelectorAll('.danger-badge');
  
  dangerBadges.forEach((badge, index) => {
    badge.style.opacity = '0';
    badge.style.transform = 'scale(0.8)';
    badge.style.transition = `all 0.3s ease ${index * 0.1}s`;
    
    setTimeout(() => {
      badge.style.opacity = '1';
      badge.style.transform = 'scale(1)';
    }, 500 + index * 100);
  });

  // ============================================
  // Console Welcome Message
  // ============================================
  console.log('%c🧠 KNOW YOUR PILL - Acute Intoxication', 'font-size: 16px; font-weight: bold; color: #ef4444;');
  console.log('%cNeuroscience Education Platform', 'font-size: 12px; color: #8b5cf6;');
  console.log('%cFor emergencies, call 112 or 14416 (Tele-MANAS)', 'font-size: 12px; color: #f97316; font-weight: bold;');
});

// ============================================
// Global Function for Emergency Call
// ============================================
function triggerEmergencyCall() {
  if (confirm('Are you in an emergency situation? This will initiate a call to emergency services.')) {
    window.location.href = 'tel:112';
  }
}

// ============================================
// Add click handler to emergency call button
// ============================================
document.addEventListener('DOMContentLoaded', function() {
  const emergencyBtn = document.querySelector('.emergency-call-button');
  if (emergencyBtn) {
    emergencyBtn.addEventListener('click', function(e) {
      // The href will handle the actual call, but we can add analytics here
      console.log('Emergency call initiated');
    });
  }
});