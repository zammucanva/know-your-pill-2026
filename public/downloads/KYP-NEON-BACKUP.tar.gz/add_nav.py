import os
import re

files_order = [
    "alcohol.html",
    "opioids.html",
    "cannabis.html",
    "cocaine.html",
    "amphetamine.html",
    "lsd.html",
    "pcp.html",
    "benzodiazepines.html",
    "barbiturate.html",
    "nicotine.html",
    "inhalants.html"
]

for i, filename in enumerate(files_order):
    filepath = os.path.join("know-your-pill", filename)
    if not os.path.exists(filepath):
        print(f"File not found: {filepath}")
        continue
    
    # Read the file
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Check if navigation already exists
    if "substance-bottom-nav" in content:
        # We will remove the old navigation first to avoid duplication
        content = re.sub(r'<div class="substance-bottom-nav">.*?</div>', '', content, flags=re.DOTALL)
    
    # Generate navigation HTML
    prev_link = "#"
    prev_disabled = " disabled"
    prev_text = "← Previous Substance"
    
    if i > 0:
        prev_link = files_order[i-1]
        prev_disabled = ""
    
    next_link = "#"
    next_disabled = " disabled"
    next_text = "Next Substance →"
    
    if i < len(files_order) - 1:
        next_link = files_order[i+1]
        next_disabled = ""
        
    nav_html = f"""<div class="substance-bottom-nav">
  <a class="substance-nav-btn secondary{prev_disabled}" href="{prev_link}">← Previous Substance</a>
  <a class="substance-nav-btn center" href="substance-use.html">Back to Substance Use</a>
  <a class="substance-nav-btn primary{next_disabled}" href="{next_link}">Next Substance →</a>
</div>"""

    # Insert right before </main>
    if "</main>" in content:
        # Let's place it before </main>
        content = content.replace("</main>", f"  {nav_html}\n  </main>")
        print(f"Added navigation to {filename}")
    else:
        print(f"Could not find </main> in {filename}")
        
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)

print("Done processing bottom nav.")