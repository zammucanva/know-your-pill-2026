# PROJECT-KYP
KNOW YOUR PILL (KYP) — A premium neuroscience-inspired psychiatric medication and substance education platform combining MBBS-level learning, neuroscience visualization, interactive medical education, and patient-friendly healthcare awareness.
Copyright © 2026 Zamaan Ali Shamji. All rights reserved.
This project is private and proprietary.
No part of this code, design, content, animations, text, images, or assets may be copied, modified, distributed, published, or used without written permission from the author.
Author: Zamaan Ali Shamji
