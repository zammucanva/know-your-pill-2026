const knownMedicines = {
  sertraline: "medicine.html?med=sertraline",
  zoloft: "medicine.html?med=sertraline",
  fluoxetine: "medicine.html?med=fluoxetine",
  prozac: "medicine.html?med=fluoxetine",
  escitalopram: "medicine.html?med=escitalopram",
  lexapro: "medicine.html?med=escitalopram"
};

const displayNames = {
  sertraline: "Sertraline",
  fluoxetine: "Fluoxetine",
  escitalopram: "Escitalopram"
};

const searchForm = document.querySelector("#medicineSearch");
const searchInput = document.querySelector("#medicineInput");
const searchHint = document.querySelector("#searchHint");
const menuToggle = document.querySelector("#menuToggle");
const siteNav = document.querySelector("#siteNav");
const heroBrain = document.querySelector(".hero-brain");
const brainSvg = document.querySelector(".brain-svg");
const helplineCards = document.querySelectorAll(".helpline-card");
const themeToggle = document.querySelector("#themeToggle");

// Add js-enabled class to body for progressive enhancement
// This ensures content is always visible, with animations as enhancement
document.documentElement.classList.add('js-enabled');
document.body.classList.add('js-enabled');

const applyTheme = (theme) => {
  const nextTheme = theme === "dark" ? "dark" : "light";
  document.documentElement.dataset.theme = nextTheme;
  localStorage.setItem("kyp-theme", nextTheme);

  if (themeToggle) {
    const isDark = nextTheme === "dark";
    themeToggle.setAttribute("aria-pressed", String(isDark));
    themeToggle.setAttribute("aria-label", isDark ? "Switch to light mode" : "Switch to dark mode");
  }
};

applyTheme(localStorage.getItem("kyp-theme") || document.documentElement.dataset.theme || "light");

if (themeToggle) {
  themeToggle.addEventListener("click", () => {
    const isDark = document.documentElement.dataset.theme === "dark";
    themeToggle.classList.remove("is-switching");
    void themeToggle.offsetWidth;
    themeToggle.classList.add("is-switching");
    applyTheme(isDark ? "light" : "dark");
    window.setTimeout(() => {
      themeToggle.classList.remove("is-switching");
    }, 620);
  });
}

if (searchForm && searchInput) {
  searchForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const query = searchInput.value.trim().toLowerCase();
    const target = knownMedicines[query];

    if (!query) {
      searchHint.textContent = "Type a medicine name first.";
      return;
    }

    if (target) {
      window.location.href = target;
      return;
    }

    searchHint.textContent = "That medicine is not built yet. Start with sertraline, fluoxetine, or escitalopram as SSRI demos.";
  });

  const searchChips = document.querySelectorAll(".search-chip");

  searchChips.forEach((chip) => {
    chip.addEventListener("click", () => {
      const value = chip.textContent.trim();
      searchInput.value = value;
      searchHint.textContent = `Ready to explore ${value}.`;
      searchInput.focus();
    });
  });
}

const params = new URLSearchParams(window.location.search);
const med = params.get("med") || "sertraline";
const medicineName = document.querySelector("#medicineName");

if (medicineName) {
  medicineName.textContent = displayNames[med] || "Sertraline";
  document.title = `${medicineName.textContent} Mechanism Demo | KNOW YOUR PILL !`;
}

// Science panel toggle for Neuro Brick
const scienceToggle = document.getElementById("scienceToggle");
const sciencePanel = document.getElementById("sciencePanel");

if (scienceToggle && sciencePanel) {
  scienceToggle.addEventListener("click", () => {
    const isExpanded = scienceToggle.getAttribute("aria-expanded") === "true";
    scienceToggle.setAttribute("aria-expanded", String(!isExpanded));
    sciencePanel.classList.toggle("is-open");
  });
}

const neuralSecretTrigger = document.getElementById("neuralSecretTrigger");
const neuralSecretCard = document.getElementById("neuralSecretCard");
const neuralSpeedPanel = document.getElementById("neuralSpeedPanel");

if (neuralSecretTrigger && neuralSecretCard) {
  neuralSecretTrigger.addEventListener("click", () => {
    const isUnlocked = neuralSecretTrigger.getAttribute("aria-expanded") === "true";
    neuralSecretTrigger.setAttribute("aria-expanded", String(!isUnlocked));
    neuralSecretTrigger.classList.toggle("is-unlocked", !isUnlocked);
    neuralSecretCard.hidden = isUnlocked;

    if (!isUnlocked && neuralSpeedPanel) {
      neuralSpeedPanel.classList.remove("is-pulsing");
      void neuralSpeedPanel.offsetWidth;
      neuralSpeedPanel.classList.add("is-pulsing");
    }
  });
}

// Active Scroll-Based Navigation Highlight System
(function() {
  const sections = document.querySelectorAll('section[id], .hero');
  const navLinks = document.querySelectorAll('.site-nav a[href^="#"]');

  // Map section IDs to nav link hrefs
  const sectionNavMap = {
    'hero': '#',
    'explore': '#explore',
    'categories': '#categories',
    'medication-library': '#medication-library',
    'neuro-game': '#neuro-game',
    'emergency': '#emergency'
  };

  // Also handle href-based matching for safety and about
  const hrefSectionMap = {
    '#safety': 'categories',
    '#about': 'hero'
  };

  let currentSection = null;
  let ticking = false;

  function getActiveSection() {
    const scrollPosition = window.scrollY + window.innerHeight / 3;

    for (let i = sections.length - 1; i >= 0; i--) {
      const section = sections[i];
      const sectionTop = section.offsetTop - 100;
      const sectionBottom = sectionTop + section.offsetHeight;

      if (scrollPosition >= sectionTop && scrollPosition < sectionBottom) {
        return section.id || 'hero';
      }
    }
    return 'hero';
  }

  function updateNavHighlight() {
    const activeSection = getActiveSection();

    if (activeSection === currentSection) {
      ticking = false;
      return;
    }

    currentSection = activeSection;

    // Remove active class from all nav links
    navLinks.forEach(link => {
      link.classList.remove('active');
    });

    // Add active class to matching nav link
    navLinks.forEach(link => {
      const href = link.getAttribute('href');
      if (href === '#' || href === sectionNavMap[activeSection]) {
        link.classList.add('active');
      }
    });

    // Special handling for safety link (maps to categories section area)
    if (activeSection === 'categories') {
      navLinks.forEach(link => {
        if (link.getAttribute('href') === '#safety') {
          link.classList.add('active');
        }
      });
    }

    ticking = false;
  }

  function onScroll() {
    if (!ticking) {
      requestAnimationFrame(updateNavHighlight);
      ticking = true;
    }
  }

  // Initial highlight
  updateNavHighlight();

  // Listen for scroll events with requestAnimationFrame throttling
  window.addEventListener('scroll', onScroll, { passive: true });

  // Handle click on nav links - set active immediately
  navLinks.forEach(link => {
    link.addEventListener('click', function() {
      navLinks.forEach(l => l.classList.remove('active'));
      this.classList.add('active');
    });
  });
})();

// Mobile navigation menu
if (menuToggle && siteNav) {
  menuToggle.addEventListener("click", () => {
    const isOpen = siteNav.classList.toggle("is-open");
    menuToggle.classList.toggle("is-open", isOpen);
    menuToggle.setAttribute("aria-expanded", String(isOpen));
    menuToggle.setAttribute("aria-label", isOpen ? "Close navigation menu" : "Open navigation menu");
  });

  siteNav.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
      siteNav.classList.remove("is-open");
      menuToggle.classList.remove("is-open");
      menuToggle.setAttribute("aria-expanded", "false");
      menuToggle.setAttribute("aria-label", "Open navigation menu");
    });
  });
}

const revealSections = document.querySelectorAll(".reveal-section");

const observer = new IntersectionObserver((entries) => {
  entries.forEach((entry) => {
    if (entry.isIntersecting) {
      entry.target.classList.add("active-reveal");
    }
  });
}, {
  threshold: 0.12
});

revealSections.forEach((section) => {
  observer.observe(section);
});

// ============================================
// Premium Accordion System - Ultra Stable (No Auto-Close)
// ============================================

class PremiumAccordion {
  constructor(container) {
    this.container = container;
    this.header = container.querySelector('.section-header.collapsible');
    this.content = container.querySelector('.collapsible-content');
    this.indicator = container.querySelector('.expand-indicator');

    if (!this.header || !this.content) return;

    this.isExpanded = false;
    this.isAnimating = false;
    this.contentInner = this.content.querySelector('.section-content');
    this.measuredHeight = 0;
    this.recalcDebounce = null;
    this.heightRecalcCount = 0;
    this.maxRecalcs = 3; // Limit recalculations to prevent loops

    // Initialize
    this.init();
  }

  init() {
    // Set initial state - use overflow: visible for content visibility
    this.content.style.maxHeight = '0';
    this.content.style.overflow = 'visible';
    this.content.style.transition = 'max-height 0.6s cubic-bezier(0.25, 1, 0.5, 1)';
    this.header.setAttribute('data-expanded', 'false');

    // DO NOT use ResizeObserver - it causes reflow loops with large content
    // Instead, use a one-time measurement after content stabilizes

    // Click handler with debouncing
    let clickTimeout = null;
    this.header.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation(); // Prevent bubbling
      if (clickTimeout || this.isAnimating) return;

      clickTimeout = setTimeout(() => {
        this.toggle();
        clickTimeout = null;
      }, 100);
    });

    // Keyboard accessibility
    this.header.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        e.stopPropagation();
        this.toggle();
      }
    });
  }

  toggle() {
    if (this.isAnimating) return;

    if (this.isExpanded) {
      this.close();
    } else {
      this.open();
    }
  }

  open() {
    if (this.isAnimating) return;
    this.isAnimating = true;
    this.heightRecalcCount = 0;

    // Update state FIRST - before any DOM changes
    this.isExpanded = true;
    this.header.setAttribute('data-expanded', 'true');

    // Animate the indicator
    if (this.indicator) {
      this.indicator.style.transform = 'rotate(180deg)';
    }

    // Wait for content to be visible and measured
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        // Get accurate scrollHeight after content is rendered
        const targetHeight = this.getFullContentHeight();
        this.measuredHeight = targetHeight;

        // Set max-height for smooth animation
        this.content.style.maxHeight = targetHeight + 'px';

        // After animation completes, set to a very large value to prevent collapse
        // This is more stable than trying to recalculate
        setTimeout(() => {
          this.isAnimating = false;
          // Use a very large max-height instead of recalculating
          // This prevents the auto-close bug caused by height recalculation loops
          this.content.style.maxHeight = '5000px';
          this.content.style.transition = 'max-height 0.3s ease';
        }, 650);
      });
    });
  }

  close() {
    if (this.isAnimating) return;
    this.isAnimating = true;

    // Update state
    this.isExpanded = false;
    this.header.setAttribute('data-expanded', 'false');

    // Reset indicator
    if (this.indicator) {
      this.indicator.style.transform = 'rotate(0deg)';
    }

    // Get current height for smooth collapse
    const currentHeight = this.content.scrollHeight;
    this.content.style.maxHeight = currentHeight + 'px';
    this.content.style.transition = 'max-height 0.4s ease';

    // Force reflow
    void this.content.offsetHeight;

    // Animate to 0
    requestAnimationFrame(() => {
      this.content.style.maxHeight = '0';
    });

    // Reset animation flag
    setTimeout(() => {
      this.isAnimating = false;
      this.content.style.transition = 'max-height 0.6s cubic-bezier(0.25, 1, 0.5, 1)';
    }, 500);
  }

  /**
   * Get the full height of all content including nested elements
   */
  getFullContentHeight() {
    if (!this.contentInner) {
      return this.content.scrollHeight || 0;
    }

    // Get the scrollHeight of the entire content wrapper
    const scrollHeight = this.contentInner.scrollHeight;

    // Get computed styles for padding
    const styles = window.getComputedStyle(this.contentInner);
    const paddingTop = parseFloat(styles.paddingTop) || 0;
    const paddingBottom = parseFloat(styles.paddingBottom) || 0;

    // Get padding from the collapsible content wrapper
    const contentStyles = window.getComputedStyle(this.content);
    const contentPaddingTop = parseFloat(contentStyles.paddingTop) || 0;
    const contentPaddingBottom = parseFloat(contentStyles.paddingBottom) || 0;

    // Total height including all padding
    const totalHeight = scrollHeight + paddingTop + paddingBottom + contentPaddingTop + contentPaddingBottom;

    // Add buffer for any animations or dynamic content
    return totalHeight + 50;
  }

  destroy() {
    clearTimeout(this.recalcDebounce);
  }
}

// Initialize all collapsible sections
const collapsibleSections = document.querySelectorAll('.learning-section .section-header.collapsible');
const accordionInstances = [];

// Wait for DOM to be fully ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initAccordions);
} else {
  initAccordions();
}

function initAccordions() {
  collapsibleSections.forEach(section => {
    const accordion = new PremiumAccordion(section.closest('.learning-section'));
    accordionInstances.push(accordion);
  });
}

// Handle window resize
let resizeTimeout;
window.addEventListener('resize', () => {
  clearTimeout(resizeTimeout);
  resizeTimeout = setTimeout(() => {
    accordionInstances.forEach(accordion => {
      if (accordion.isExpanded) {
        accordion.recalculateHeight();
      }
    });
  }, 200);
});

// Original simple toggle for non-content accordions
const simpleCollapsibleHeaders = document.querySelectorAll('.section-header.collapsible:not(.learning-section .section-header.collapsible)');

simpleCollapsibleHeaders.forEach(header => {
  header.addEventListener('click', () => {
    const isExpanded = header.getAttribute('data-expanded') === 'true';
    header.setAttribute('data-expanded', String(!isExpanded));
  });
});

// Clinical Foundations - Premium Expanding Accordion System
const pathwayCards = document.querySelectorAll(".pathway-card");
const pathwayGrid = document.querySelector(".pathway-grid");

// Smooth expanding accordion with cinematic transitions
pathwayCards.forEach((card) => {
  const handleClick = () => {
    const isExpanded = card.classList.contains("is-expanded");
    const wasAnyExpanded = document.querySelector(".pathway-card.is-expanded");

    // Close all cards first with smooth transition
    pathwayCards.forEach((otherCard) => {
      otherCard.classList.remove("is-expanded");
      otherCard.setAttribute("aria-expanded", "false");
    });

    // If card wasn't expanded, expand it after a brief delay for smooth transition
    if (!isExpanded) {
      // Use requestAnimationFrame for smooth layout transition
      requestAnimationFrame(() => {
        requestAnimationFrame(() => {
          card.classList.add("is-expanded");
          card.setAttribute("aria-expanded", "true");

          // Smooth scroll to keep expanded card in view
          setTimeout(() => {
            const cardRect = card.getBoundingClientRect();
            const viewportHeight = window.innerHeight;

            if (cardRect.bottom > viewportHeight - 100) {
              card.scrollIntoView({ behavior: "smooth", block: "center" });
            }
          }, 100);
        });
      });
    }
  };

  // Click handler with smooth interaction
  card.addEventListener("click", (e) => {
    e.preventDefault();
    handleClick();
  });

  // Keyboard handler for accessibility
  card.addEventListener("keydown", (e) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      handleClick();
    }
  });
});

// Emergency support accordion
if (helplineCards.length) {
  const closeHelplineCard = (card) => {
    const toggle = card.querySelector(".helpline-toggle");
    const panel = card.querySelector(".helpline-panel");

    card.classList.remove("is-open");
    toggle?.setAttribute("aria-expanded", "false");

    if (panel) {
      panel.style.maxHeight = "0px";
    }
  };

  const openHelplineCard = (card) => {
    const toggle = card.querySelector(".helpline-toggle");
    const panel = card.querySelector(".helpline-panel");

    helplineCards.forEach((otherCard) => {
      if (otherCard !== card) closeHelplineCard(otherCard);
    });

    card.classList.add("is-open");
    toggle?.setAttribute("aria-expanded", "true");

    if (panel) {
      panel.style.maxHeight = `${panel.scrollHeight}px`;
    }
  };

  helplineCards.forEach((card) => {
    closeHelplineCard(card);

    card.addEventListener("click", (event) => {
      if (event.target.closest("a")) return;

      if (card.classList.contains("is-open")) {
        closeHelplineCard(card);
        return;
      }

      openHelplineCard(card);
    });
  });

  window.addEventListener("resize", () => {
    const openCard = document.querySelector(".helpline-card.is-open .helpline-panel");
    if (openCard) {
      openCard.style.maxHeight = `${openCard.scrollHeight}px`;
    }
  });
}

// Homepage SVG brain hero
if (heroBrain && brainSvg) {
  const animate = window.gsap;

  if (animate) {
    animate.fromTo(heroBrain, { opacity: 0, y: 18, scale: 0.98 }, { opacity: 1, y: 0, scale: 1, duration: 0.9, ease: "power3.out", delay: 0.2 });
    animate.to(brainSvg, { y: -12, duration: 4.8, yoyo: true, repeat: -1, ease: "sine.inOut" });
  }

  heroBrain.addEventListener("pointermove", (event) => {
    const rect = heroBrain.getBoundingClientRect();
    const x = ((event.clientX - rect.left) / rect.width - 0.5) * 2;
    const y = ((event.clientY - rect.top) / rect.height - 0.5) * 2;

    if (animate) {
      animate.to(brainSvg, { rotateY: x * 5, rotateX: y * -4, scale: 1.015, duration: 0.45, ease: "power2.out" });
    } else {
      brainSvg.style.transform = `rotateY(${x * 5}deg) rotateX(${y * -4}deg)`;
    }
  });

  heroBrain.addEventListener("pointerleave", () => {
    if (animate) {
      animate.to(brainSvg, { rotateY: 0, rotateX: 0, scale: 1, duration: 0.45, ease: "power2.out" });
    } else {
      brainSvg.style.transform = "";
    }
  });
}

// Neuro Arcade - Brain Breakout Game
const canvas = document.getElementById("brainBreakout");
if (canvas) {
  const ctx = canvas.getContext("2d");
  let animationFrameId = null;
  let gameOver = false;
  let gameWon = false;
  let gameOverFade = 0;
  let gameStarted = false;
  const speedPanel = document.getElementById("neuralSpeedPanel");
  const speedButtons = document.querySelectorAll("[data-speed-mode]");
  const activeSpeedLabel = document.getElementById("activeSpeedLabel");
  const adaptiveIndicator = document.getElementById("adaptiveIndicator");
  const speedNotification = document.getElementById("speedNotification");
  const speedMeterFill = document.getElementById("speedMeterFill");
  const speedModes = {
    normal: {
      label: "Normal Neural Response",
      shortLabel: "Normal",
      baseSpeed: 10.2,
      minSpeed: 9.4,
      maxSpeed: 11.1,
      meter: "60%",
      paddleSpeed: 12.75
    },
    medium: {
      label: "Accelerated Processing",
      shortLabel: "Medium",
      baseSpeed: 12.25,
      minSpeed: 11.1,
      maxSpeed: 13.25,
      meter: "78%",
      paddleSpeed: 14.75
    },
    fast: {
      label: "Hyper-Reaction Mode",
      shortLabel: "Fast",
      baseSpeed: 14.35,
      minSpeed: 13.25,
      maxSpeed: 15.6,
      meter: "100%",
      paddleSpeed: 17
    },
    mixed: {
      label: "Adaptive Neural Load",
      shortLabel: "Mixed Random",
      baseSpeed: 12.1,
      minSpeed: 9.8,
      maxSpeed: 15,
      meter: "88%",
      paddleSpeed: 15.5
    }
  };
  let activeSpeedMode = "normal";
  let currentBallSpeed = speedModes.normal.baseSpeed;
  let targetBallSpeed = speedModes.normal.baseSpeed;
  let speedPulse = 0;
  let speedHudMessage = "Normal Neural Response";
  let speedHudOpacity = 0;
  let nextMixedSpeedChange = 0;

  // Random color palette for each game session (neon/futuristic colors)
  const neonPalettes = [
    { ball: "#5b7cff", paddle: "#ff4fa3", bricks: ["#7c83ff", "#ff5ca8"] },
    { ball: "#00f5d4", paddle: "#f72585", bricks: ["#7209b7", "#4361ee"] },
    { ball: "#f72585", paddle: "#4cc9f0", bricks: ["#7209b7", "#4895ef"] },
    { ball: "#4cc9f0", paddle: "#f72585", bricks: ["#3a0ca3", "#560bad"] },
    { ball: "#7209b7", paddle: "#f72585", bricks: ["#4361ee", "#4895ef"] },
    { ball: "#4361ee", paddle: "#f72585", bricks: ["#7209b7", "#3a0ca3"] },
    { ball: "#06d6a0", paddle: "#ef476f", bricks: ["#118ab2", "#073b4c"] },
    { ball: "#ffd166", paddle: "#06d6a0", bricks: ["#118ab2", "#073b4c"] },
  ];

  let currentPalette;

  // Game variables - will be initialized in initGame()
  let paddleWidth, paddleHeight, paddleX, ballRadius, x, y, dx, dy;
  let rightPressed, leftPressed;
  const brickRowCount = 5;
  const brickColumnCount = 10;
  const brickWidth = 70;
  const brickHeight = 22;
  const brickPadding = 12;
  const brickOffsetTop = 112;
  const brickOffsetLeft = 52;
  let score;
  let lives;
  let bricks;

  function getRandomPalette() {
    return neonPalettes[Math.floor(Math.random() * neonPalettes.length)];
  }

  function getSpeedModeConfig() {
    return speedModes[activeSpeedMode] || speedModes.normal;
  }

  function clampSpeed(speed, config = getSpeedModeConfig()) {
    return Math.min(config.maxSpeed, Math.max(config.minSpeed, speed));
  }

  function setVelocityMagnitude(speed) {
    const magnitude = Math.hypot(dx || 0, dy || 0) || speedModes.normal.baseSpeed;
    const nextSpeed = clampSpeed(speed);
    dx = (dx / magnitude) * nextSpeed;
    dy = (dy / magnitude) * nextSpeed;
  }

  function setLaunchVelocity(direction = Math.random() > 0.5 ? 1 : -1) {
    const launchSpeed = clampSpeed(targetBallSpeed);
    const component = launchSpeed / Math.sqrt(2);
    dx = component * direction;
    dy = -component;
    currentBallSpeed = launchSpeed;
  }

  function triggerSpeedFeedback(message) {
    speedPulse = 1;
    speedHudMessage = message;
    speedHudOpacity = 1;

    if (speedPanel) {
      speedPanel.classList.remove("is-pulsing");
      void speedPanel.offsetWidth;
      speedPanel.classList.add("is-pulsing");
    }

    if (speedNotification) {
      speedNotification.textContent = `${message} engaged`;
      speedNotification.classList.remove("is-pulsing");
      void speedNotification.offsetWidth;
      speedNotification.classList.add("is-pulsing");
    }
  }

  function scheduleNextMixedSpeedChange(now = performance.now()) {
    nextMixedSpeedChange = now + 2400 + Math.random() * 2600;
  }

  function setSpeedMode(mode) {
    if (!speedModes[mode]) return;

    activeSpeedMode = mode;
    const config = getSpeedModeConfig();
    targetBallSpeed = config.baseSpeed;

    if (activeSpeedLabel) activeSpeedLabel.textContent = config.label;
    if (speedMeterFill) speedMeterFill.style.width = config.meter;
    if (adaptiveIndicator) adaptiveIndicator.classList.toggle("is-active", mode === "mixed");

    speedButtons.forEach((button) => {
      const isActive = button.dataset.speedMode === mode;
      button.classList.toggle("is-active", isActive);
      button.setAttribute("aria-pressed", String(isActive));
    });

    if (mode === "mixed") {
      scheduleNextMixedSpeedChange();
    }

    if (!gameStarted || gameOver) {
      currentBallSpeed = targetBallSpeed;
      if (typeof dx === "number" && typeof dy === "number") {
        setVelocityMagnitude(currentBallSpeed);
      }
    }

    triggerSpeedFeedback(config.label);
  }

  function updateMixedRandomSpeed(now) {
    if (activeSpeedMode !== "mixed" || now < nextMixedSpeedChange) return;

    const config = getSpeedModeConfig();
    targetBallSpeed = config.minSpeed + Math.random() * (config.maxSpeed - config.minSpeed);
    scheduleNextMixedSpeedChange(now);
    triggerSpeedFeedback("Adaptive neural speed shift");
  }

  function updateSpeedInterpolation(now) {
    updateMixedRandomSpeed(now);
    const config = getSpeedModeConfig();
    targetBallSpeed = clampSpeed(targetBallSpeed, config);
    currentBallSpeed += (targetBallSpeed - currentBallSpeed) * 0.045;
    setVelocityMagnitude(currentBallSpeed);

    if (speedPulse > 0) speedPulse *= 0.93;
    if (speedHudOpacity > 0) speedHudOpacity *= 0.985;
  }

  function initGame() {
    // Pick a random color palette on each game start/restart
    currentPalette = getRandomPalette();

    paddleWidth = 140;
    paddleHeight = 14;
    paddleX = canvas.width / 2 - paddleWidth / 2;
    ballRadius = 12;
    x = canvas.width / 2;
    y = canvas.height - 60;
    targetBallSpeed = getSpeedModeConfig().baseSpeed;
    currentBallSpeed = targetBallSpeed;
    setLaunchVelocity();
    rightPressed = false;
    leftPressed = false;
    score = 0;
    lives = 3;
    gameOver = false;
    gameWon = false;
    gameOverFade = 0;

    bricks = [];
    for (let c = 0; c < brickColumnCount; c++) {
      bricks[c] = [];
      for (let r = 0; r < brickRowCount; r++) {
        bricks[c][r] = {
          x: 0,
          y: 0,
          status: 1
        };
      }
    }
  }

  function drawBall() {
    ctx.beginPath();
    ctx.arc(x, y, ballRadius, 0, Math.PI * 2);
    ctx.fillStyle = currentPalette.ball;
    ctx.fill();
    // Add glow effect to ball
    ctx.shadowColor = currentPalette.ball;
    ctx.shadowBlur = 12 + currentBallSpeed * 2 + speedPulse * 20;
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.closePath();
  }

  function drawPaddle() {
    ctx.beginPath();
    ctx.roundRect(paddleX, canvas.height - paddleHeight - 20, paddleWidth, paddleHeight, 10);
    ctx.fillStyle = currentPalette.paddle;
    ctx.fill();
    // Add glow effect to paddle
    ctx.shadowColor = currentPalette.paddle;
    ctx.shadowBlur = 12;
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.closePath();
  }

  function drawBricks() {
    for (let c = 0; c < brickColumnCount; c++) {
      for (let r = 0; r < brickRowCount; r++) {
        if (bricks[c][r].status === 1) {
          let brickX = (c * (brickWidth + brickPadding)) + brickOffsetLeft;
          let brickY = (r * (brickHeight + brickPadding)) + brickOffsetTop;
          bricks[c][r].x = brickX;
          bricks[c][r].y = brickY;
          ctx.beginPath();
          ctx.roundRect(brickX, brickY, brickWidth, brickHeight, 8);
          ctx.fillStyle = currentPalette.bricks[r % 2];
          ctx.fill();
          // Add subtle glow to bricks
          ctx.shadowColor = currentPalette.bricks[r % 2];
          ctx.shadowBlur = 8;
          ctx.fill();
          ctx.shadowBlur = 0;
          ctx.closePath();
        }
      }
    }
  }

  function collisionDetection() {
    for (let c = 0; c < brickColumnCount; c++) {
      for (let r = 0; r < brickRowCount; r++) {
        let b = bricks[c][r];
        if (b.status === 1) {
          if (x > b.x && x < b.x + brickWidth && y > b.y && y < b.y + brickHeight) {
            dy = -dy;
            b.status = 0;
            score++;
            if (score === brickRowCount * brickColumnCount) {
              gameWon = true;
              gameOver = true;
            }
          }
        }
      }
    }
  }

  function drawScore() {
    drawGameplayHud();
  }

  function drawGameplayHud() {
    const config = getSpeedModeConfig();
    const speedRatio = (currentBallSpeed - 9.4) / (15.6 - 9.4);
    const hudX = 18;
    const hudY = 18;
    const hudWidth = canvas.width - 36;
    const hudHeight = 58;
    const chipHeight = 38;
    const scoreWidth = 156;
    const livesWidth = 150;
    const gap = 12;
    const speedWidth = hudWidth - scoreWidth - livesWidth - gap * 2;
    const speedX = hudX + scoreWidth + gap;
    const livesX = speedX + speedWidth + gap;

    ctx.save();
    ctx.beginPath();
    ctx.roundRect(hudX, hudY, hudWidth, hudHeight, 24);
    ctx.fillStyle = "rgba(255, 255, 255, 0.74)";
    ctx.shadowColor = currentPalette.ball;
    ctx.shadowBlur = 12 + speedPulse * 20;
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.strokeStyle = "rgba(124, 131, 255, 0.28)";
    ctx.lineWidth = 1.5;
    ctx.stroke();

    drawHudChip(hudX + 12, hudY + 10, scoreWidth, chipHeight, "NEURAL SCORE", String(score).padStart(2, "0"), currentPalette.ball);

    ctx.beginPath();
    ctx.roundRect(speedX, hudY + 10, speedWidth, chipHeight, 16);
    ctx.fillStyle = "rgba(255, 255, 255, 0.6)";
    ctx.fill();
    ctx.strokeStyle = "rgba(91, 124, 255, 0.18)";
    ctx.stroke();

    ctx.font = "bold 10px 'Segoe UI', Arial, sans-serif";
    ctx.fillStyle = "#5b7cff";
    ctx.textAlign = "left";
    ctx.fillText("ACTIVE NEURAL MODE", speedX + 14, hudY + 25);

    ctx.font = "bold 15px 'Segoe UI', Arial, sans-serif";
    ctx.fillStyle = "#111827";
    ctx.fillText(config.shortLabel, speedX + 14, hudY + 43);

    const meterX = speedX + Math.min(168, speedWidth * 0.45);
    const meterY = hudY + 28;
    const meterWidth = Math.max(70, speedWidth - (meterX - speedX) - 16);
    const fillWidth = Math.max(16, Math.min(meterWidth, meterWidth * speedRatio));
    ctx.beginPath();
    ctx.roundRect(meterX, meterY, meterWidth, 9, 9);
    ctx.fillStyle = "rgba(91, 124, 255, 0.12)";
    ctx.fill();

    const gradient = ctx.createLinearGradient(meterX, meterY, meterX + meterWidth, meterY);
    gradient.addColorStop(0, "#06b6d4");
    gradient.addColorStop(0.55, "#5b7cff");
    gradient.addColorStop(1, "#ff4fa3");
    ctx.beginPath();
    ctx.roundRect(meterX, meterY, fillWidth, 9, 9);
    ctx.fillStyle = gradient;
    ctx.fill();

    drawLivesChip(livesX, hudY + 10, livesWidth, chipHeight);

    if (speedHudOpacity > 0.06) {
      ctx.globalAlpha = Math.min(0.92, speedHudOpacity);
      ctx.beginPath();
      ctx.roundRect(canvas.width / 2 - 160, hudY + hudHeight + 12, 320, 30, 15);
      ctx.fillStyle = "rgba(255, 255, 255, 0.78)";
      ctx.fill();
      ctx.font = "bold 13px 'Segoe UI', Arial, sans-serif";
      ctx.fillStyle = "#5b21b6";
      ctx.textAlign = "center";
      ctx.fillText(speedHudMessage, canvas.width / 2, hudY + hudHeight + 32);
    }

    ctx.restore();
  }

  function drawHudChip(chipX, chipY, chipWidth, chipHeight, label, value, glowColor) {
    ctx.save();
    ctx.beginPath();
    ctx.roundRect(chipX, chipY, chipWidth, chipHeight, 16);
    ctx.fillStyle = "rgba(255, 255, 255, 0.62)";
    ctx.fill();
    ctx.strokeStyle = "rgba(91, 124, 255, 0.18)";
    ctx.stroke();

    ctx.fillStyle = "#5b7cff";
    ctx.font = "bold 10px 'Segoe UI', Arial, sans-serif";
    ctx.textAlign = "left";
    ctx.fillText(label, chipX + 14, chipY + 17);

    ctx.shadowColor = glowColor;
    ctx.shadowBlur = 14;
    ctx.fillStyle = "#111827";
    ctx.font = "bold 22px 'Segoe UI', Arial, sans-serif";
    ctx.fillText(value, chipX + 14, chipY + 34);
    ctx.restore();
  }

  function drawLivesChip(chipX, chipY, chipWidth, chipHeight) {
    ctx.save();
    ctx.beginPath();
    ctx.roundRect(chipX, chipY, chipWidth, chipHeight, 16);
    ctx.fillStyle = "rgba(255, 255, 255, 0.62)";
    ctx.fill();
    ctx.strokeStyle = "rgba(255, 79, 163, 0.2)";
    ctx.stroke();

    ctx.fillStyle = "#ff4fa3";
    ctx.font = "bold 10px 'Segoe UI', Arial, sans-serif";
    ctx.textAlign = "left";
    ctx.fillText("NEURAL LIVES", chipX + 14, chipY + 17);

    for (let i = 0; i < 3; i++) {
      const alpha = i < lives ? 1 : 0.18;
      ctx.globalAlpha = alpha;
      drawHeart(chipX + 24 + i * 28, chipY + 20, 16);
    }

    ctx.restore();
  }

  function drawLives() {
    const heartSize = 18;
    const startX = canvas.width - 40;
    const y = 28;

    for (let i = 0; i < lives; i++) {
      drawHeart(startX - (i * (heartSize + 8)), y, heartSize);
    }
  }

  function drawHeart(x, y, size) {
    ctx.save();
    ctx.fillStyle = "#ef4444";
    ctx.shadowColor = "#ef4444";
    ctx.shadowBlur = 10;
    ctx.beginPath();
    const topCurveHeight = size * 0.3;
    ctx.moveTo(x, y + topCurveHeight);
    // top left curve
    ctx.bezierCurveTo(
      x, y,
      x - size / 2, y,
      x - size / 2, y + topCurveHeight
    );
    // bottom left curve
    ctx.bezierCurveTo(
      x - size / 2, y + (size + topCurveHeight) / 2,
      x, y + (size + topCurveHeight) / 2,
      x, y + size
    );
    // bottom right curve
    ctx.bezierCurveTo(
      x, y + (size + topCurveHeight) / 2,
      x + size / 2, y + (size + topCurveHeight) / 2,
      x + size / 2, y + topCurveHeight
    );
    // top right curve
    ctx.bezierCurveTo(
      x + size / 2, y,
      x, y,
      x, y + topCurveHeight
    );
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  function drawStartScreen() {
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;

    // Draw semi-transparent overlay
    ctx.fillStyle = "rgba(17, 24, 39, 0.85)";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw start game box
    const boxWidth = 420;
    const boxHeight = 280;
    const boxX = centerX - boxWidth / 2;
    const boxY = centerY - boxHeight / 2;

    // Box shadow/glow
    ctx.save();
    ctx.shadowColor = "#5b7cff";
    ctx.shadowBlur = 40;
    ctx.beginPath();
    ctx.roundRect(boxX, boxY, boxWidth, boxHeight, 24);
    ctx.fillStyle = "rgba(255, 255, 255, 0.12)";
    ctx.fill();
    ctx.restore();

    // Box background with glass effect
    ctx.beginPath();
    ctx.roundRect(boxX, boxY, boxWidth, boxHeight, 24);
    ctx.fillStyle = "rgba(30, 41, 59, 0.8)";
    ctx.fill();

    // Box border
    ctx.beginPath();
    ctx.roundRect(boxX, boxY, boxWidth, boxHeight, 24);
    ctx.strokeStyle = "rgba(91, 124, 255, 0.5)";
    ctx.lineWidth = 2;
    ctx.stroke();

    // Inner glow line
    ctx.beginPath();
    ctx.roundRect(boxX + 3, boxY + 3, boxWidth - 6, boxHeight - 6, 22);
    ctx.strokeStyle = "rgba(255, 255, 255, 0.08)";
    ctx.lineWidth = 1;
    ctx.stroke();

    // Title
    ctx.save();
    ctx.shadowColor = "#5b7cff";
    ctx.shadowBlur = 30;
    ctx.font = "bold 48px 'Segoe UI', Arial, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    const gradient = ctx.createLinearGradient(centerX - 100, centerY - 60, centerX + 100, centerY);
    gradient.addColorStop(0, "#5b7cff");
    gradient.addColorStop(0.5, "#a78bfa");
    gradient.addColorStop(1, "#7c83ff");
    ctx.fillStyle = gradient;
    ctx.fillText("NEURO BRICK", centerX, centerY - 40);
    ctx.restore();

    // Subtitle
    ctx.font = "bold 18px 'Segoe UI', Arial, sans-serif";
    ctx.fillStyle = "#9ca3af";
    ctx.textAlign = "center";
    ctx.fillText("Brain Breakout Challenge", centerX, centerY + 15);

    // Start instruction
    ctx.save();
    ctx.shadowColor = "#06b6d4";
    ctx.shadowBlur = 15;
    ctx.font = "bold 20px 'Segoe UI', Arial, sans-serif";
    ctx.fillStyle = "#06b6d4";
    ctx.textAlign = "center";
    ctx.fillText("Press SPACE or Click to Start", centerX, centerY + 65);
    ctx.restore();

    // Controls hint
    ctx.font = "14px 'Segoe UI', Arial, sans-serif";
    ctx.fillStyle = "#6b7280";
    ctx.textAlign = "center";
    ctx.fillText("Use Arrow Keys or Mouse to Move", centerX, centerY + 100);
  }

  function drawGameOver() {
    const centerX = canvas.width / 2;
    const centerY = canvas.height / 2;

    // Draw blurred overlay background
    ctx.fillStyle = `rgba(17, 24, 39, ${Math.min(gameOverFade, 0.85)})`;
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    if (gameOverFade < 0.85) {
      gameOverFade += 0.02;
    }

    // Draw glassmorphism game-over box
    const boxWidth = 420;
    const boxHeight = 300;
    const boxX = centerX - boxWidth / 2;
    const boxY = centerY - boxHeight / 2;

    // Box shadow/glow
    ctx.save();
    ctx.shadowColor = gameWon ? "#7c83ff" : "#ff4fa3";
    ctx.shadowBlur = 40;
    ctx.beginPath();
    ctx.roundRect(boxX, boxY, boxWidth, boxHeight, 24);
    ctx.fillStyle = "rgba(255, 255, 255, 0.12)";
    ctx.fill();
    ctx.restore();

    // Box background with glass effect
    ctx.beginPath();
    ctx.roundRect(boxX, boxY, boxWidth, boxHeight, 24);
    ctx.fillStyle = "rgba(30, 41, 59, 0.75)";
    ctx.fill();

    // Box border
    ctx.beginPath();
    ctx.roundRect(boxX, boxY, boxWidth, boxHeight, 24);
    ctx.strokeStyle = gameWon ? "rgba(124, 131, 255, 0.5)" : "rgba(255, 79, 163, 0.5)";
    ctx.lineWidth = 2;
    ctx.stroke();

    // Inner glow line
    ctx.beginPath();
    ctx.roundRect(boxX + 3, boxY + 3, boxWidth - 6, boxHeight - 6, 22);
    ctx.strokeStyle = "rgba(255, 255, 255, 0.08)";
    ctx.lineWidth = 1;
    ctx.stroke();

    // Draw "GAME OVER" or "YOU WIN" text with gradient
    const mainText = gameWon ? "YOU WIN!" : "GAME OVER";
    const subText = "Press SPACE to Restart";

    // Glow effect for main text
    ctx.save();
    ctx.shadowColor = gameWon ? "#7c83ff" : "#ff4fa3";
    ctx.shadowBlur = 30;
    ctx.font = "bold 48px 'Segoe UI', Arial, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";

    // Gradient for main text
    const gradient = ctx.createLinearGradient(centerX - 120, centerY - 50, centerX + 120, centerY + 10);
    if (gameWon) {
      gradient.addColorStop(0, "#7c83ff");
      gradient.addColorStop(0.5, "#a78bfa");
      gradient.addColorStop(1, "#5b7cff");
    } else {
      gradient.addColorStop(0, "#ff4fa3");
      gradient.addColorStop(0.5, "#ff7cb8");
      gradient.addColorStop(1, "#ff5ca8");
    }
    ctx.fillStyle = gradient;
    ctx.fillText(mainText, centerX, centerY - 40);
    ctx.restore();

    // Draw restart instruction
    ctx.save();
    ctx.shadowColor = "#5b7cff";
    ctx.shadowBlur = 15;
    ctx.font = "bold 20px 'Segoe UI', Arial, sans-serif";
    ctx.fillStyle = "#5b7cff";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(subText, centerX, centerY + 30);
    ctx.restore();

    // Draw final score
    ctx.font = "bold 24px 'Segoe UI', Arial, sans-serif";
    ctx.fillStyle = "#e5e7eb";
    ctx.textAlign = "center";
    ctx.fillText(`Final Score: ${score}`, centerX, centerY + 70);
  }

  function draw() {
    if (!gameStarted) {
      drawStartScreen();
      return;
    }

    if (gameOver) {
      drawGameOver();
      return;
    }

    ctx.clearRect(0, 0, canvas.width, canvas.height);
    drawBricks();
    drawBall();
    drawPaddle();
    drawScore();
    collisionDetection();
    updateSpeedInterpolation(performance.now());

    if (x + dx > canvas.width - ballRadius || x + dx < ballRadius) {
      dx = -dx;
    }

    if (y + dy < ballRadius) {
      dy = -dy;
    } else if (y + dy > canvas.height - ballRadius - 20) {
      if (x > paddleX && x < paddleX + paddleWidth) {
        dy = -dy;
        // Add slight speed increase on paddle hit for more challenge
        targetBallSpeed = clampSpeed(targetBallSpeed * 1.012);
      } else {
        lives--;
        if (lives <= 0) {
          gameOver = true;
        } else {
          // Reset ball position and speed
          x = canvas.width / 2;
          y = canvas.height - 60;
          targetBallSpeed = getSpeedModeConfig().baseSpeed;
          setLaunchVelocity();
          paddleX = canvas.width / 2 - paddleWidth / 2;
        }
      }
    }

    if (rightPressed && paddleX < canvas.width - paddleWidth) {
      paddleX += getSpeedModeConfig().paddleSpeed;
    }
    if (leftPressed && paddleX > 0) {
      paddleX -= getSpeedModeConfig().paddleSpeed;
    }

    x += dx;
    y += dy;
    animationFrameId = requestAnimationFrame(draw);
  }

  function keyDownHandler(e) {
    if (e.key === "Right" || e.key === "ArrowRight") {
      rightPressed = true;
    } else if (e.key === "Left" || e.key === "ArrowLeft") {
      leftPressed = true;
    } else if (e.key === " " || e.key === "Space") {
      e.preventDefault();
      if (!gameStarted) {
        startGame();
      } else if (gameOver) {
        restartGame();
      }
    }
  }

  function keyUpHandler(e) {
    if (e.key === "Right" || e.key === "ArrowRight") {
      rightPressed = false;
    } else if (e.key === "Left" || e.key === "ArrowLeft") {
      leftPressed = false;
    }
  }

  function mouseMoveHandler(e) {
    if (!gameStarted || gameOver) return;
    const rect = canvas.getBoundingClientRect();
    const relativeX = (e.clientX - rect.left) * (canvas.width / rect.width);
    if (relativeX > 0 && relativeX < canvas.width) {
      paddleX = relativeX - paddleWidth / 2;
    }
  }

  function canvasClickHandler(e) {
    if (!gameStarted) {
      startGame();
    }
  }

  function startGame() {
    gameStarted = true;
    if (activeSpeedMode === "mixed") {
      scheduleNextMixedSpeedChange();
    }
    draw();
  }

  function restartGame() {
    // Cancel the current animation frame
    if (animationFrameId !== null) {
      cancelAnimationFrame(animationFrameId);
      animationFrameId = null;
    }

    // Re-initialize game state
    initGame();
    if (activeSpeedMode === "mixed") {
      scheduleNextMixedSpeedChange();
    }

    // Start the game loop again
    draw();
  }

  speedButtons.forEach((button) => {
    button.addEventListener("click", () => {
      setSpeedMode(button.dataset.speedMode);
    });
  });

  // Initialize and show start screen
  initGame();
  setSpeedMode(activeSpeedMode);
  document.addEventListener("keydown", keyDownHandler);
  document.addEventListener("keyup", keyUpHandler);
  canvas.addEventListener("mousemove", mouseMoveHandler);
  canvas.addEventListener("click", canvasClickHandler);
  draw();
}

// ============================================
// MBBS Clinical Mode - Mode Toggle & ICD Interactions
// ============================================

document.addEventListener('DOMContentLoaded', function() {
  // Mode Toggle Functionality
  const modeToggleBtns = document.querySelectorAll('.mode-toggle-btn');
  const neuroscienceContent = document.getElementById('neuroscience-content');
  const mbbsContent = document.getElementById('mbbs-content');

  if (modeToggleBtns.length > 0) {
    modeToggleBtns.forEach(btn => {
      btn.addEventListener('click', function() {
        const mode = this.dataset.mode;
        
        // Update button states
        modeToggleBtns.forEach(b => {
          b.classList.remove('active');
          b.setAttribute('aria-pressed', 'false');
        });
        this.classList.add('active');
        this.setAttribute('aria-pressed', 'true');
        
        // Switch content
        if (mode === 'mbbs') {
          neuroscienceContent.style.display = 'none';
          mbbsContent.style.display = 'block';
        } else {
          mbbsContent.style.display = 'none';
          neuroscienceContent.style.display = 'block';
        }
      });
    });
  }

  // Pathway Expand/Collapse Functionality
  const pathwayExpands = document.querySelectorAll('.pathway-expand');
  
  pathwayExpands.forEach(expand => {
    expand.addEventListener('click', function() {
      const targetId = this.dataset.target;
      const targetContent = document.getElementById(targetId);
      
      if (targetContent) {
        const isExpanded = this.classList.contains('expanded');
        
        // Close all other expanded pathways
        pathwayExpands.forEach(e => {
          e.classList.remove('expanded');
          const otherTarget = document.getElementById(e.dataset.target);
          if (otherTarget && otherTarget !== targetContent) {
            otherTarget.style.display = 'none';
          }
        });
        
        // Toggle current
        if (isExpanded) {
          this.classList.remove('expanded');
          targetContent.style.display = 'none';
        } else {
          this.classList.add('expanded');
          targetContent.style.display = 'block';
        }
      }
    });
  });

  // ICD Chip Click Functionality
  const icdChips = document.querySelectorAll('.icd-chip');
  const icdClinicalCard = document.getElementById('icd-clinical-card');
  const icdBadge = document.getElementById('icd-badge');
  const icdTitle = document.getElementById('icd-title');
  const icdCriteria = document.getElementById('icd-criteria');
  const icdEmergency = document.getElementById('icd-emergency');
  const icdNeuro = document.getElementById('icd-neuro');
  const icdPrognosis = document.getElementById('icd-prognosis');
  const icdPearls = document.getElementById('icd-pearls');

  const icdData = {
    'F1x.0': {
      title: 'Acute Intoxication',
      criteria: 'Clear evidence of recent substance use, with clinically significant problematic behavioral or psychological changes that developed during or shortly after substance use.',
      emergency: ['Respiratory depression', 'Unconsciousness', 'Seizures'],
      neuro: ['Dopamine ↑', 'GABA modulation', 'Glutamate ↓'],
      prognosis: 'Usually complete recovery unless complications such as trauma or aspiration occur. Duration depends on substance half-life and metabolic clearance.',
      pearls: [
        'ABCs first — secure airway, breathing, circulation',
        'Check glucose — hypoglycemia can mimic intoxication',
        'Consider naloxone if opioid overdose suspected',
        'Monitor for co-ingestants and polysubstance use'
      ]
    },
    'F1x.1': {
      title: 'Harmful Use',
      criteria: 'A pattern of substance use that is causing damage to physical or mental health. Evidence should clearly show that substance use is related to the damage.',
      emergency: ['Hepatic failure', 'Suicidal ideation', 'Severe malnutrition'],
      neuro: ['Prefrontal cortex impairment', 'Reward system dysregulation'],
      prognosis: 'Reversible if use stops early. Continued use often progresses to dependence syndrome with more severe health consequences.',
      pearls: [
        'Screen for depression and anxiety comorbidities',
        'Assess social support and living situation',
        'Brief intervention can be highly effective at this stage',
        'Document specific health damage for motivational interviewing'
      ]
    },
    'F1x.2': {
      title: 'Dependence Syndrome',
      criteria: 'A cluster of physiological, behavioral, and cognitive phenomena where substance use takes priority over other behaviors. Requires 3+ symptoms for 1+ month.',
      emergency: ['Overdose risk', 'Severe withdrawal', 'Polydrug toxicity'],
      neuro: ['Dopamine D2 receptor downregulation', 'Glutamate system sensitization', 'Prefrontal hypoactivity'],
      prognosis: 'Chronic relapsing condition. With comprehensive treatment, sustained remission is achievable. Neuroplasticity allows partial brain recovery over months to years.',
      pearls: [
        'Assess readiness to change using transtheoretical model',
        'Consider medication-assisted treatment for opioids/alcohol',
        'Address co-occurring psychiatric disorders simultaneously',
        'Involve family in treatment planning when appropriate'
      ]
    },
    'F1x.3': {
      title: 'Withdrawal State',
      criteria: 'A group of symptoms of variable clustering and severity occurring on absolute or relative withdrawal of a substance after repeated, and usually prolonged use.',
      emergency: ['Delirium tremens', 'Seizures', 'Severe dehydration'],
      neuro: ['GABA downregulation', 'Glutamate upregulation', 'Autonomic hyperactivity'],
      prognosis: 'Acute withdrawal typically resolves in 5-14 days. Post-acute withdrawal symptoms (PAWS) may persist for months. Medical supervision reduces mortality risk.',
      pearls: [
        'Use CIWA-Ar or COWS scales for objective monitoring',
        'Benzodiazepines for alcohol/benzo withdrawal',
        'Thiamine before glucose in alcohol withdrawal',
        'Taper slowly to prevent rebound symptoms'
      ]
    },
    'F1x.4': {
      title: 'Withdrawal with Delirium',
      criteria: 'Delirium occurring during withdrawal, characterized by clouding of consciousness, reduced ability to focus, and perceptual disturbances.',
      emergency: ['Hyperthermia', 'Cardiovascular collapse', 'Status epilepticus'],
      neuro: ['Severe GABA/glutamate imbalance', 'Cholinergic deficit', 'Cytokine storm'],
      prognosis: 'Medical emergency with 1-4% mortality if untreated. With proper management, delirium typically resolves in 3-7 days. Early recognition is critical.',
      pearls: [
        'ICU admission often required for monitoring',
        'High-dose benzodiazepines or phenobarbital protocols',
        'Correct electrolyte imbalances aggressively',
        'Avoid physical restraints — increases rhabdomyolysis risk'
      ]
    },
    'F1x.5': {
      title: 'Psychotic Disorder',
      criteria: 'A cluster of psychotic phenomena (delusions, hallucinations, thought disorder) occurring during or within 2 weeks of substance use, not better explained by primary psychosis.',
      emergency: ['Command hallucinations', 'Paranoid violence risk', 'Catatonia'],
      neuro: ['Mesolimbic dopamine hyperactivity', '5-HT2A overstimulation', 'Hippocampal dysfunction'],
      prognosis: 'Usually resolves within 1 month of abstinence. Persistent psychosis beyond 6 months suggests primary psychotic disorder unmasked by substance use.',
      pearls: [
        'Rule out medical causes (infection, metabolic)',
        'Atypical antipsychotics preferred over typical',
        'Monitor for NMS if using antipsychotics',
        'Substance-induced psychosis has higher violence risk'
      ]
    },
    'F1x.6': {
      title: 'Amnesic Syndrome',
      criteria: 'Impairment of recent and remote memory with preserved immediate recall and consciousness. Associated with chronic heavy use, particularly alcohol.',
      emergency: ['Wernicke encephalopathy triad', 'Confabulation with safety risk'],
      neuro: ['Mammillary body atrophy', 'Thalamic damage', 'Hippocampal neurotoxicity'],
      prognosis: 'Wernicke phase is reversible with thiamine. Korsakoff phase is often permanent with only partial recovery. Prevention through early thiamine is critical.',
      pearls: [
        'Give parenteral thiamine BEFORE glucose administration',
        'High-dose thiamine for 3-5 days, then oral maintenance',
        'Assess nutritional status — multiple deficiencies common',
        'Long-term custodial care may be needed for severe cases'
      ]
    },
    'F1x.7': {
      title: 'Residual/Late-Onset Disorder',
      criteria: 'Disorders persisting beyond the period of acute substance effects, including cognitive impairment, mood disorders, or personality changes.',
      emergency: ['Progressive dementia', 'Severe depression with suicidality'],
      neuro: ['White matter changes', 'Cortical atrophy', 'Neuroinflammation'],
      prognosis: 'Variable. Some cognitive recovery occurs over 6-12 months of abstinence. Persistent deficits may require long-term support and rehabilitation.',
      pearls: [
        'Neuropsychological testing for baseline assessment',
        'Cognitive rehabilitation can improve functioning',
        'Monitor for neurodegenerative disease progression',
        'Address vascular risk factors to optimize brain health'
      ]
    }
  };

  icdChips.forEach(chip => {
    chip.addEventListener('click', function() {
      const icdCode = this.dataset.icd;
      const data = icdData[icdCode];
      
      if (data && icdClinicalCard) {
        // Update card content
        icdBadge.textContent = icdCode;
        icdTitle.textContent = data.title;
        icdCriteria.textContent = data.criteria;
        icdPrognosis.textContent = data.prognosis;
        
        // Update emergency tags
        icdEmergency.innerHTML = data.emergency.map(tag => 
          `<span class="tag-emergency">${tag}</span>`
        ).join('');
        
        // Update neuro tags
        icdNeuro.innerHTML = data.neuro.map(tag => 
          `<span class="tag-neuro">${tag}</span>`
        ).join('');
        
        // Update pearls
        icdPearls.innerHTML = data.pearls.map(pearl => 
          `<li>${pearl}</li>`
        ).join('');
        
        // Show card with animation
        icdClinicalCard.style.display = 'block';
        icdClinicalCard.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
      }
    });
  });
});

// Close ICD Card function (called from HTML onclick)
function closeIcdCard() {
 const icdClinicalCard = document.getElementById('icd-clinical-card');
 if (icdClinicalCard) {
 icdClinicalCard.style.display = 'none';
 }
}
