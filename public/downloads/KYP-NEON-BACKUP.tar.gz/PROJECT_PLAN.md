# Medication Animation Website Project Plan

Author: Zamaan Ali Shamji

Goal: Build a psychiatry-focused medication education website with brain-mechanism animations for patients and students.

## Project Vision

Build a website that explains psychiatric medications visually using animations showing:

- what happens after taking the medicine
- how medicine travels in the body
- how it reaches the brain
- which receptors/pathways are affected
- when effects begin
- why doctors prescribe it
- common side effects
- emergency warning signs
- missed dose guidance
- unsafe combinations in a later phase

The website should help patients, caregivers, MBBS students, and later NEET-PG aspirants.

Start with psychiatry medicines first, then later expand to all medical drugs.

## Platform Strategy

Phase 1 is website only and browser-based.

Reasons:

- works on iOS browsers automatically
- works on Android browsers automatically
- faster to build
- easier to update
- no app-store approval required
- lower complexity

Phase 2 may convert the website into mobile apps if needed.

## Primary Website Flow

The user enters a medicine name. The website displays:

1. medicine overview
2. why prescribed
3. animation of brain mechanism
4. timeline of effects
5. side effects
6. emergency warning signs
7. missed dose instructions
8. unsafe combinations in a later phase

## First Target Content Area

Psychiatric medication classes:

1. Antidepressants, starting with SSRIs
2. Antipsychotics
3. Mood stabilizers
4. Anti-anxiety medicines
5. Sleep medicines
6. ADHD medicines in a later phase

## Version 1 Tech Stack

- HTML
- CSS
- JavaScript
- Lottie animations

## Project Folder Structure

```text
medbrain-site/
  index.html
  medicine.html
  style.css
  script.js
  animations/
  images/
```

## Roadmap

Week 1: install Visual Studio Code, setup project folder, create homepage layout.

Week 2: build medicine search bar.

Week 3: build first psychiatry medicine category page.

Week 4: add first animation module for SSRI mechanism.

Week 5: add safety warning section.

Week 6: publish working prototype online.

## Project Purpose

- Help patients understand medicines visually
- Reduce fear about psychiatric treatment
- Improve medication awareness
- Assist students learning pharmacology
- Provide emergency guidance support
- Create a scalable medical education platform
